import { createApp } from 'vue'
import App from './App.vue'
import 'animate.css'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import './styles/element-theme.css'
import './styles/sr-style.css'
import HSRButton from './components/HSRButton.vue'
import HSRInput from './components/HSRInput.vue'

const app = createApp(App)
app.component('HSRButton', HSRButton)
app.component('HSRInput', HSRInput)
app.use(ElementPlus)
app.mount('#app')