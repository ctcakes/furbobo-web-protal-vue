// 安全过滤工具函数

// 过滤评论、回复等用户输入的内容
export const sanitizeContent = (content) => {
  if (!content) return '';
  
  let result = content.toString();
  
  // 移除危险字符：<>{}$&|;`\
  result = result.replace(/[<>{}$&|;`\\]/g, '');
  
  return result;
};

// 过滤用户名（只允许字母、数字、下划线和中文）
export const sanitizeUsername = (username) => {
  if (!username) return '';
  
  let result = username.toString();
  
  // 只保留字母、数字、下划线和中文
  result = result.replace(/[^a-zA-Z0-9_\u4e00-\u9fa5]/g, '');
  
  return result;
};

// 过滤HTML内容（保留格式化标签，只移除危险内容）
export const sanitizeHtmlContent = (html) => {
  if (!html) return '';
  
  let result = html.toString();
  
  // 移除 script 标签及其内容
  result = result.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
  
  // 移除 on* 事件属性（如 onclick、onload 等）
  result = result.replace(/\s+on\w+\s*=\s*["'][^"']*["']/gi, '');
  
  // 移除 javascript: 协议
  result = result.replace(/javascript:/gi, '');
  
  // 移除 data: 协议（除了图片）
  result = result.replace(/data:(?!image\/).*/gi, '');
  
  // 移除 style 属性中的危险内容
  result = result.replace(/style\s*=\s*["'][^"']*(?:expression|url\s*\(\s*javascript:)[^"']*["']/gi, '');
  
  // 移除 iframe 标签
  result = result.replace(/<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi, '');
  
  // 移除 object 标签
  result = result.replace(/<object\b[^<]*(?:(?!<\/object>)<[^<]*)*<\/object>/gi, '');
  
  // 移除 embed 标签
  result = result.replace(/<embed\b[^<]*>/gi, '');
  
  return result;
};