<template>
  <div v-if="show" class="confirm-modal-overlay" :class="{ 'show': true, 'hiding': isClosing }">
    <div class="confirm-modal" :class="{ 'closing': isClosing }">
      <div class="confirm-modal-header">
        <span class="confirm-modal-title">{{ title }}</span>
      </div>

      <div class="confirm-modal-content">
        <div class="confirm-message">{{ message }}</div>
      </div>

      <div class="confirm-modal-footer">
        <HSRButton size="small" :tag="null" :custom-icon="cancelIcon" :icon-size="18"
          @click="handleCancel" :disabled="loading">
          取消
        </HSRButton>
        <HSRButton size="small" :tag="null" :custom-icon="confirmIcon" :icon-size="16"
          @click="handleConfirm" :loading="loading">
          确认
        </HSRButton>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import HSRButton from './HSRButton.vue';

const props = defineProps({
  show: {
    type: Boolean,
    default: false
  },
  title: {
    type: String,
    default: '确认'
  },
  message: {
    type: String,
    default: '是否确认此操作？'
  },
  loading: {
    type: Boolean,
    default: false
  }
});

const emit = defineEmits(['confirm', 'cancel', 'close']);

const isClosing = ref(false);

// 取消图标 - 使用cuo.png
const cancelIcon = new URL('@/assets/cuo.png', import.meta.url).href;

// 确认图标 - 使用youcun.png
const confirmIcon = new URL('@/assets/youcun.png', import.meta.url).href;

// 取消按钮
const handleCancel = () => {
  isClosing.value = true;
  setTimeout(() => {
    emit('cancel');
    emit('close');
    isClosing.value = false;
  }, 250);
};

// 确认按钮
const handleConfirm = () => {
  if (!props.loading) {
    emit('confirm');
  }
};

// 监听show变化，处理关闭动画
const handleClose = () => {
  isClosing.value = true;
  setTimeout(() => {
    emit('close');
    isClosing.value = false;
  }, 250);
};
</script>

<style scoped>
.confirm-modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2000;
  backdrop-filter: blur(0px);
  opacity: 0;
  animation: fadeInOverlay 0.2s ease-out forwards;
}

.confirm-modal-overlay.show {
  background-color: rgba(0, 0, 0, 0.5);
  opacity: 1;
  backdrop-filter: blur(5px);
  animation: fadeInOverlayWithBlur 0.2s ease-out forwards;
}

.confirm-modal-overlay.closing {
  animation: fadeOutOverlayWithBlur 0.2s ease-in forwards;
}

.confirm-modal {
  width: 800px;
  max-width: 90%;
  height: 360px;
  background-color: white;
  border-radius: 10px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
  display: flex;
  flex-direction: column;
  transform: translateY(-100px);
  opacity: 0;
  overflow: hidden;
  position: relative;
  animation: slideInFromTop 0.3s cubic-bezier(0.16, 0.8, 0.37, 0.99) forwards;
}

.confirm-modal.closing {
  animation: slideOutToTop 0.25s cubic-bezier(0.16, 0.8, 0.37, 0.99) forwards;
}

.confirm-modal-header {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 20px 24px;
  border-bottom: 1px solid #e8e8e8;
  background: #fafafa;
}

.confirm-modal-title {
  font-size: 18px;
  font-weight: 600;
  color: #333;
  margin: 0;
}

.confirm-modal-content {
  padding: 32px 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex: 1;
}

.confirm-message {
  font-size: 20px;
  color: #333;
  text-align: center;
  line-height: 1.6;
}

.confirm-modal-footer {
  display: flex;
  justify-content: center;
  gap: 16px;
  padding: 16px 24px;
  border-top: 1px solid #e8e8e8;
  background: #fafafa;
  background-image: url('@/assets/dialog_bg.png');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}

.confirm-modal-footer .sr-action-btn {
  min-width: 200px;
}

/* 动画效果 */
@keyframes fadeInOverlay {
  from {
    background-color: rgba(0, 0, 0, 0);
    opacity: 0;
  }

  to {
    background-color: rgba(0, 0, 0, 0.5);
    opacity: 1;
  }
}

@keyframes fadeInOverlayWithBlur {
  from {
    background-color: rgba(0, 0, 0, 0);
    opacity: 0;
    backdrop-filter: blur(0px);
  }

  to {
    background-color: rgba(0, 0, 0, 0.5);
    opacity: 1;
    backdrop-filter: blur(5px);
  }
}

@keyframes fadeOutOverlayWithBlur {
  from {
    background-color: rgba(0, 0, 0, 0.5);
    opacity: 1;
    backdrop-filter: blur(5px);
  }

  to {
    background-color: rgba(0, 0, 0, 0);
    opacity: 0;
    backdrop-filter: blur(0px);
  }
}

@keyframes slideInFromTop {
  from {
    transform: translateY(-100px);
    opacity: 0;
  }

  to {
    transform: translateY(0);
    opacity: 1;
  }
}

@keyframes slideOutToTop {
  from {
    transform: translateY(0);
    opacity: 1;
  }

  to {
    transform: translateY(-100px);
    opacity: 0;
  }
}
</style>