<template>
  <div v-if="show" class="post-modal-overlay" :class="{ 'show': true, 'hiding': isClosing }">
    <div class="post-modal" :class="{ 'closing': isClosing }">
      <div class="post-header">
        <h3 class="post-title">发布新帖</h3>
        <button class="post-close" @click="handleClose">
          <img src="@/assets/close.png" class="close-icon" alt="关闭" />
        </button>
      </div>

      <div class="post-content">
        <!-- 文章标题 -->
        <div class="form-group">
          <label>文章标题</label>
          <input
            v-model="postTitle"
            type="text"
            placeholder="请输入文章标题"
            maxlength="100"
          />
        </div>

        <!-- 文章图片上传 -->
        <div class="form-group">
          <label>文章图片（最多1张，自动设为封面）</label>
          <div class="image-upload-area">
            <div class="image-list">
              <div v-for="(image, index) in postImages" :key="index" class="image-item" 
                   draggable="true"
                   @dragstart="handleDragStart(index)"
                   @dragover.prevent
                   @dragenter.prevent
                   @drop="handleDrop(index)">
                <img :src="image" class="image-preview" />
                <div class="cover-badge">封面</div>
                <button class="remove-image-btn" @click="removeImage(index)">×</button>
              </div>
              <div v-if="postImages.length < 1" class="upload-btn" @click="triggerFileUpload">
                <span>+</span>
                <span>添加图片</span>
              </div>
            </div>
            <div class="upload-tip">支持 JPG、PNG 格式，建议尺寸 200x200px</div>
          </div>
        </div>

        <!-- 文章内容编辑器 -->
        <div class="form-group">
          <label>文章内容</label>
          <div class="editor-wrapper">
            <div class="editor-toolbar" v-if="editor">
              <!-- 撤销/重做 -->
              <button type="button" class="toolbar-btn" @click="editor.chain().focus().undo().run()" :disabled="!editor.can().undo()" title="撤销">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="16" height="16"><path fill="currentColor" d="M204.8 358.4V204.8h204.8v-102.4H102.4v460.8h102.4V568.32c56.96 76.16 149.248 128 256 128 198.912 0 358.4-159.488 358.4-358.4s-159.488-358.4-358.4-358.4c-70.912 0-137.728 20.48-194.56 56.32l64 89.6c39.424-24.576 86.016-38.4 135.68-38.4 141.312 0 256 114.688 256 256S607.312 614.4 460.8 614.4c-102.4 0-189.952-59.904-230.4-148.48z"></path></svg>
              </button>
              <button type="button" class="toolbar-btn" @click="editor.chain().focus().redo().run()" :disabled="!editor.can().redo()" title="重做">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="16" height="16"><path fill="currentColor" d="M819.2 358.4V204.8H614.4v-102.4h307.2v460.8h-102.4V568.32c-56.96 76.16-149.248 128-256 128-198.912 0-358.4-159.488-358.4-358.4S264.488-20.48 460.8-20.48c70.912 0 137.728 20.48 194.56 56.32l-64 89.6c-39.424-24.576-86.016-38.4-135.68-38.4-141.312 0-256 114.688-256 256s114.688 256 256 256c102.4 0 189.952-59.904 230.4-148.48z"></path></svg>
              </button>
              
              <div class="toolbar-divider"></div>
              
              <!-- 标题级别 -->
              <div class="toolbar-select">
                <select @change="(e) => editor.chain().focus().toggleHeading({ level: parseInt(e.target.value) }).run()">
                  <option value="">正文</option>
                  <option value="1">标题 1</option>
                  <option value="2">标题 2</option>
                  <option value="3">标题 3</option>
                  <option value="4">标题 4</option>
                  <option value="5">标题 5</option>
                  <option value="6">标题 6</option>
                </select>
              </div>
              
              <div class="toolbar-divider"></div>
              
              <!-- 文本样式 -->
              <button type="button" class="toolbar-btn" :class="{ active: editor.isActive('bold') }" @click="editor.chain().focus().toggleBold().run()" title="加粗">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="16" height="16"><path fill="currentColor" d="M665.6 921.6H358.4V102.4H665.6c70.656 0 128 57.344 128 128V358.4c0 45.568-24.32 85.504-60.672 108.8 36.352 23.296 60.672 63.232 60.672 108.8V793.6c0 70.656-57.344 128-128 128m-28.16-358.4H409.6v281.6h227.84c35.328 0 64-28.672 64-64v-153.6c0-35.328-28.672-64-64-64m0-281.6H409.6v217.6h227.84c35.328 0 64-28.672 64-64v-89.6c0-35.328-28.672-64-64-64"></path></svg>
              </button>
              <button type="button" class="toolbar-btn" :class="{ active: editor.isActive('italic') }" @click="editor.chain().focus().toggleItalic().run()" title="斜体">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="16" height="16"><path fill="currentColor" d="M384 1024h-51.2l179.2-1024H563.2l-179.2 1024z"></path></svg>
              </button>
              <button type="button" class="toolbar-btn" :class="{ active: editor.isActive('underline') }" @click="editor.chain().focus().toggleUnderline().run()" title="下划线">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="16" height="16"><path fill="currentColor" d="M204.8 870.4h614.4v51.2H204.8zM512 0c-113.28 0-204.8 91.52-204.8 204.8v358.4h102.4V204.8c0-56.32 45.76-102.4 102.4-102.4 56.32 0 102.4 46.08 102.4 102.4v358.4h102.4V204.8C716.8 91.52 625.28 0 512 0"></path></svg>
              </button>
              <button type="button" class="toolbar-btn" :class="{ active: editor.isActive('strike') }" @click="editor.chain().focus().toggleStrike().run()" title="删除线">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="16" height="16"><path fill="currentColor" d="M512 0C229.248 0 0 229.248 0 512s229.248 512 512 512 512-229.248 512-512S794.752 0 512 0m0 947.2c-240.128 0-435.2-195.072-435.2-435.2S271.872 76.8 512 76.8s435.2 195.072 435.2 435.2-195.072 435.2-435.2 435.2M307.2 486.4h409.6v51.2H307.2z"></path></svg>
              </button>
              
              <div class="toolbar-divider"></div>
              
              <!-- 文本颜色 -->
              <button type="button" class="toolbar-btn" @click="setTextColor('#000000')" title="黑色文字">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="16" height="16"><circle cx="512" cy="512" r="512" fill="#000000"/></svg>
              </button>
              <button type="button" class="toolbar-btn" @click="setTextColor('#ed8f23')" title="橙色文字">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="16" height="16"><circle cx="512" cy="512" r="512" fill="#ed8f23"/></svg>
              </button>
              <button type="button" class="toolbar-btn" @click="setTextColor('#ff4d4f')" title="红色文字">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="16" height="16"><circle cx="512" cy="512" r="512" fill="#ff4d4f"/></svg>
              </button>
              <button type="button" class="toolbar-btn" @click="setTextColor('#52c41a')" title="绿色文字">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="16" height="16"><circle cx="512" cy="512" r="512" fill="#52c41a"/></svg>
              </button>
              <button type="button" class="toolbar-btn" @click="setTextColor('#1890ff')" title="蓝色文字">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="16" height="16"><circle cx="512" cy="512" r="512" fill="#1890ff"/></svg>
              </button>
              
              <div class="toolbar-divider"></div>
              
              <!-- 对齐方式 -->
              <button type="button" class="toolbar-btn" :class="{ active: editor.isActive({ textAlign: 'left' }) }" @click="editor.chain().focus().setTextAlign('left').run()" title="左对齐">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="16" height="16"><path fill="currentColor" d="M128 153.6h768v102.4H128V153.6m0 256h512v102.4H128V409.6m0 256h768v102.4H128V665.6z"></path></svg>
              </button>
              <button type="button" class="toolbar-btn" :class="{ active: editor.isActive({ textAlign: 'center' }) }" @click="editor.chain().focus().setTextAlign('center').run()" title="居中对齐">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="16" height="16"><path fill="currentColor" d="M128 153.6h768v102.4H128V153.6m0 256h768v102.4H128V409.6m0 256h768v102.4H128V665.6z"></path></svg>
              </button>
              <button type="button" class="toolbar-btn" :class="{ active: editor.isActive({ textAlign: 'right' }) }" @click="editor.chain().focus().setTextAlign('right').run()" title="右对齐">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="16" height="16"><path fill="currentColor" d="M128 153.6h768v102.4H128V153.6m256 256h512v102.4H384V409.6m-256 256h768v102.4H128V665.6z"></path></svg>
              </button>
              <button type="button" class="toolbar-btn" :class="{ active: editor.isActive({ textAlign: 'justify' }) }" @click="editor.chain().focus().setTextAlign('justify').run()" title="两端对齐">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="16" height="16"><path fill="currentColor" d="M128 153.6h768v102.4H128V153.6m0 256h768v102.4H128V409.6m0 256h768v102.4H128V665.6z"></path></svg>
              </button>
              
              <div class="toolbar-divider"></div>
              
              <!-- 列表 -->
              <button type="button" class="toolbar-btn" :class="{ active: editor.isActive('bulletList') }" @click="editor.chain().focus().toggleBulletList().run()" title="无序列表">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="16" height="16"><path fill="currentColor" d="M204.8 256a102.4 102.4 0 1 0 0-204.8 102.4 102.4 0 0 0 0 204.8m0 256a102.4 102.4 0 1 0 0-204.8 102.4 102.4 0 0 0 0 204.8m0 256a102.4 102.4 0 1 0 0-204.8 102.4 102.4 0 0 0 0 204.8M358.4 153.6h512v51.2H358.4zM358.4 409.6h512v51.2H358.4zM358.4 665.6h512v51.2H358.4z"></path></svg>
              </button>
              <button type="button" class="toolbar-btn" :class="{ active: editor.isActive('orderedList') }" @click="editor.chain().focus().toggleOrderedList().run()" title="有序列表">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="16" height="16"><path fill="currentColor" d="M153.6 153.6h76.8v51.2h-76.8v-51.2m0 256h76.8v51.2h-76.8v-51.2m0 256h76.8v51.2h-76.8v-51.2M307.2 153.6h512v51.2H307.2zM307.2 409.6h512v51.2H307.2zM307.2 665.6h512v51.2H307.2z"></path></svg>
              </button>
              
              <div class="toolbar-divider"></div>
              
              <!-- 其他功能 -->
              <button type="button" class="toolbar-btn" :class="{ active: editor.isActive('blockquote') }" @click="editor.chain().focus().toggleBlockquote().run()" title="引用">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="16" height="16"><path fill="currentColor" d="M153.6 563.2h204.8v307.2H153.6v-307.2m0-409.6h204.8v307.2H153.6V153.6m512 409.6h204.8v307.2h-204.8v-307.2m0-409.6h204.8v307.2h-204.8V153.6z"></path></svg>
              </button>
              <button type="button" class="toolbar-btn" :class="{ active: editor.isActive('codeBlock') }" @click="editor.chain().focus().toggleCodeBlock().run()" title="代码块">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="16" height="16"><path fill="currentColor" d="M317.44 716.8l-153.6-204.8 153.6-204.8 76.8 51.2-128 153.6 128 153.6zM706.56 716.8l153.6-204.8-153.6-204.8-76.8 51.2 128 153.6-128 153.6zM547.84 768l-102.4-512 89.6-25.6 102.4 512z"></path></svg>
              </button>
              <button type="button" class="toolbar-btn" @click="editor.chain().focus().setHorizontalRule().run()" title="分割线">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="16" height="16"><path fill="currentColor" d="M128 486.4h768v51.2H128z"></path></svg>
              </button>
              
              <div class="toolbar-divider"></div>
              
              <!-- 链接和图片 -->
              <button type="button" class="toolbar-btn" :class="{ active: editor.isActive('link') }" @click="editor.isActive('link') ? removeLink() : addLink()" title="链接">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="16" height="16"><path fill="currentColor" d="M870.4 378.88L645.12 153.6a102.4 102.4 0 0 0-144.896 0L378.88 274.944l76.8 76.8 121.344-121.344a25.6 25.6 0 0 1 36.224 0l225.28 225.28a25.6 25.6 0 0 1 0 36.224L616.704 614.4l76.8 76.8 177.152-177.152a102.4 102.4 0 0 0 0-144.896m-353.28 353.28L395.776 853.504a25.6 25.6 0 0 1-36.224 0l-225.28-225.28a25.6 25.6 0 0 1 0-36.224L256.256 469.76l-76.8-76.8L2.048 570.112a102.4 102.4 0 0 0 0 144.896l225.28 225.28a102.4 102.4 0 0 0 144.896 0l314.368-314.368-76.8-76.8z"></path></svg>
              </button>
              
              <div class="toolbar-divider"></div>
              
              <!-- 清除格式 -->
              <button type="button" class="toolbar-btn" @click="editor.chain().focus().unsetAllMarks().run()" title="清除格式">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="16" height="16"><path fill="currentColor" d="M204.8 204.8h614.4v614.4H204.8V204.8m-51.2-51.2v716.8h716.8V153.6H153.6z"></path></svg>
              </button>
            </div>
            <div class="editor-container">
              <editor-content :editor="editor" />
            </div>
          </div>
        </div>

        <!-- 提交按钮 -->
        <div class="form-actions">
          <HSRButton size="large" :tag="null" :custom-icon-svg="confirmIconSvg" :icon-size="18"
            @click="handleSubmit" :loading="loading">
            发布
          </HSRButton>
        </div>
      </div>
    </div>
  </div>

  <!-- 输入链接模态框 -->
  <InputModal
    :show="showInputModal"
    title="添加链接"
    label="链接地址"
    placeholder="请输入链接地址（如：https://example.com）"
    @confirm="handleLinkConfirm"
    @cancel="handleLinkCancel"
    @close="handleLinkClose"
  />
</template>

<script setup>
import { ref, watch, onMounted, onBeforeUnmount } from 'vue';
import { useEditor, EditorContent } from '@tiptap/vue-3';
import StarterKit from '@tiptap/starter-kit';
import { TextAlign } from '@tiptap/extension-text-align';
import { TextStyle } from '@tiptap/extension-text-style';
import { Color } from '@tiptap/extension-color';
import Underline from '@tiptap/extension-underline';
import Link from '@tiptap/extension-link';
import Blockquote from '@tiptap/extension-blockquote';
import HorizontalRule from '@tiptap/extension-horizontal-rule';
import CodeBlockLowlight from '@tiptap/extension-code-block-lowlight';
import { ElMessage } from 'element-plus';
import HSRButton from './HSRButton.vue';
import InputModal from './InputModal.vue';
import { sanitizeContent, sanitizeHtmlContent } from '../utils/security';

// 导入低亮库
import { common, createLowlight } from 'lowlight';

// 创建低亮实例
const lowlight = createLowlight(common);

const props = defineProps({
  show: {
    type: Boolean,
    default: false
  }
});

const emit = defineEmits(['close', 'submit']);

// 状态
const isClosing = ref(false);
const loading = ref(false);
const postTitle = ref('');
const postImages = ref([]);
const showInputModal = ref(false);

// SVG 图标
const confirmIconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024"><path fill="currentColor" d="M160 832h704a32 32 0 1 1 0 64H160a32 32 0 1 1 0-64m384-578.304V704h-64V247.296L237.248 490.048 192 444.8 508.8 128l316.8 316.8-45.312 45.248z"></path></svg>`;

// 初始化 TipTap 编辑器
const editor = useEditor({
  extensions: [
    StarterKit.configure({
      codeBlock: false // 使用 CodeBlockLowlight 替代
    }),
    TextAlign.configure({
      types: ['heading', 'paragraph']
    }),
    TextStyle,
    Color,
    Underline,
    Link.configure({
      openOnClick: false,
      HTMLAttributes: {
        target: '_blank'
      }
    }),
    Blockquote,
    HorizontalRule,
    CodeBlockLowlight.configure({
      lowlight
    })
  ],
  content: '',
  editorProps: {
    attributes: {
      class: 'prose prose-sm sm:prose lg:prose-lg xl:prose-2xl mx-auto focus:outline-none'
    }
  },
  onUpdate: () => {
    // 可以在这里添加自动保存等功能
  }
});

// 监听模态框显示状态
watch(() => props.show, (newVal) => {
  if (newVal) {
    // 打开模态框时重置表单
    postTitle.value = '';
    postImages.value = [];
    if (editor.value) {
      editor.value.commands.setContent('');
    }
    isClosing.value = false;
  }
});

// 触发文件上传
const triggerFileUpload = () => {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'image/*';
  input.multiple = false;
  input.onchange = (e) => {
    const files = Array.from(e.target.files);
    if (files.length > 0) {
      postImages.value = []; // 清空现有图片
      const file = files[0];
      const reader = new FileReader();
      reader.onload = (e) => {
        postImages.value.push(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };
  input.click();
};

// 删除图片
const removeImage = (index) => {
  postImages.value.splice(index, 1);
};

// 拖拽排序
const draggedIndex = ref(null);

const handleDragStart = (index) => {
  draggedIndex.value = index;
};

const handleDrop = (dropIndex) => {
  if (draggedIndex.value === null || draggedIndex.value === dropIndex) return;
  
  const draggedImage = postImages.value[draggedIndex.value];
  postImages.value.splice(draggedIndex.value, 1);
  postImages.value.splice(dropIndex, 0, draggedImage);
  
  draggedIndex.value = null;
};

// 添加链接
const addLink = () => {
  showInputModal.value = true;
};

const handleLinkConfirm = (url) => {
  if (url) {
    editor.value.chain().focus().setLink({ href: url }).run();
  }
};

const handleLinkCancel = () => {
  // 取消操作，什么都不做
};

const handleLinkClose = () => {
  showInputModal.value = false;
};

// 移除链接
const removeLink = () => {
  editor.value.chain().focus().unsetLink().run();
};

// 设置文本颜色
const setTextColor = (color) => {
  editor.value.chain().focus().setColor(color).run();
};

// 提交表单
const handleSubmit = async () => {
  if (!postTitle.value.trim()) {
    ElMessage.warning('请输入文章标题');
    return;
  }

  if (!editor.value || !editor.value.getText().trim()) {
    ElMessage.warning('请输入文章内容');
    return;
  }

  loading.value = true;

  try {
    // 获取编辑器内容（HTML格式）
    const content = editor.value.getHTML();

    // 过滤标题和内容，移除危险字符
    const sanitizedTitle = sanitizeContent(postTitle.value.trim());
    const sanitizedContent = sanitizeHtmlContent(content);

    // 准备提交数据
    const postData = {
      title: sanitizedTitle,
      content: sanitizedContent,
      images: postImages.value
    };

    // 触发提交事件
    emit('submit', postData);

    // 关闭模态框
    handleClose();
  } catch (error) {
    console.error('提交失败:', error);
    ElMessage.error('提交失败，请重试');
  } finally {
    loading.value = false;
  }
};

// 关闭模态框（带动画）
const handleClose = () => {
  isClosing.value = true;
  setTimeout(() => {
    emit('close');
    isClosing.value = false;
  }, 250); // 与CSS动画时长一致
};

// 组件卸载时销毁编辑器
onBeforeUnmount(() => {
  if (editor.value) {
    editor.value.destroy();
  }
});
</script>

<style scoped>
.post-modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2000;
  backdrop-filter: blur(0px);
  opacity: 0;
  animation: fadeInOverlay 0.2s ease-out forwards;
}

.post-modal-overlay.show {
  background-color: rgba(0, 0, 0, 0.5);
  opacity: 1;
  backdrop-filter: blur(5px);
  animation: fadeInOverlayWithBlur 0.2s ease-out forwards;
}

.post-modal-overlay.closing {
  animation: fadeOutOverlayWithBlur 0.2s ease-in forwards;
}

.post-modal-overlay.hiding {
  animation: fadeOutOverlayWithBlur 0.25s ease-in forwards;
}

.post-modal {
  width: 900px;
  max-width: 95%;
  max-height: 90vh;
  background-color: white;
  border-radius: 10px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
  display: flex;
  flex-direction: column;
  transform: translateY(-100px);
  opacity: 0;
  overflow: hidden;
  position: relative;
  animation: slideInFromTop 0.3s cubic-bezier(0.16, 0.8, 0.37, 0.99) forwards;
}

.post-modal.closing {
  animation: slideOutToTop 0.25s cubic-bezier(0.16, 0.8, 0.37, 0.99) forwards;
}

.post-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px 24px;
  border-bottom: 1px solid #e8e8e8;
  background: #fafafa;
}

.post-title {
  font-size: 20px;
  font-weight: 600;
  color: #333;
  margin: 0;
}

.post-close {
  background: none;
  border: none;
  cursor: pointer;
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  transition: background-color 0.2s;
  padding: 0;
}

.post-close:hover {
  background-color: #e0e0e0;
}

.close-icon {
  width: 18px;
  height: 18px;
  object-fit: contain;
}

.post-content {
  flex: 1;
  overflow-y: auto;
  padding: 24px;
}

.form-group {
  margin-bottom: 24px;
}

.form-group label {
  display: block;
  font-size: 14px;
  font-weight: 600;
  color: #333;
  margin-bottom: 8px;
}

.form-group input[type="text"] {
  width: 100%;
  padding: 12px 16px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 14px;
  transition: border-color 0.2s;
  box-sizing: border-box;
}

.form-group input[type="text"]:focus {
  outline: none;
  border-color: #ed8f23;
}

.image-upload-area {
  border: 2px dashed #ddd;
  border-radius: 8px;
  padding: 16px;
  background: #fafafa;
}

.image-list {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
}

.image-item {
  position: relative;
  width: 120px;
  height: 120px;
  border-radius: 6px;
  overflow: hidden;
  border: 2px solid #e0e0e0;
  cursor: move;
  transition: all 0.2s;
}

.image-item:hover {
  border-color: #ed8f23;
}

.image-item.dragging {
  opacity: 0.5;
  transform: scale(0.95);
}

.image-preview {
  width: 100%;
  height: 100%;
  object-fit: cover;
  pointer-events: none;
  user-select: none;
}

.cover-badge {
  position: absolute;
  top: 4px;
  left: 4px;
  background: #ed8f23;
  color: white;
  font-size: 10px;
  padding: 2px 6px;
  border-radius: 3px;
  font-weight: 600;
}

.remove-image-btn {
  position: absolute;
  top: 4px;
  right: 4px;
  width: 20px;
  height: 20px;
  background: rgba(0, 0, 0, 0.6);
  color: white;
  border: none;
  border-radius: 50%;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 16px;
  line-height: 1;
  transition: background-color 0.2s;
}

.remove-image-btn:hover {
  background: rgba(0, 0, 0, 0.8);
}

.upload-btn {
  width: 120px;
  height: 120px;
  border: 2px dashed #999;
  border-radius: 6px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.2s;
  color: #999;
}

.upload-btn:hover {
  border-color: #ed8f23;
  color: #ed8f23;
  background: rgba(237, 143, 35, 0.05);
}

.upload-btn span:first-child {
  font-size: 32px;
  font-weight: 300;
  line-height: 1;
  margin-bottom: 4px;
}

.upload-btn span:last-child {
  font-size: 12px;
}

.editor-wrapper {
  border: 1px solid #ddd;
  border-radius: 6px;
  overflow: hidden;
}

.editor-toolbar {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 8px;
  background: #fafafa;
  border-bottom: 1px solid #ddd;
  flex-wrap: wrap;
}

.toolbar-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  border: 1px solid #e0e0e0;
  background: white;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.2s;
  padding: 0;
}

.toolbar-btn:hover:not(:disabled) {
  background: #f0f0f0;
  border-color: #d0d0d0;
}

.toolbar-btn:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}

.toolbar-btn.active {
  background: #ed8f23;
  border-color: #ed8f23;
  color: white;
}

.toolbar-btn.active svg {
  fill: white;
}

.toolbar-select {
  position: relative;
}

.toolbar-select select {
  padding: 4px 8px;
  border: 1px solid #e0e0e0;
  border-radius: 4px;
  background: white;
  cursor: pointer;
  font-size: 13px;
  height: 32px;
  min-width: 80px;
}

.toolbar-select select:hover {
  border-color: #d0d0d0;
}

.toolbar-select select:focus {
  outline: none;
  border-color: #ed8f23;
}

.toolbar-divider {
  width: 1px;
  height: 20px;
  background: #e0e0e0;
  margin: 0 4px;
}

.editor-container {
  min-height: 300px;
  overflow: hidden;
}

.editor-container :deep(.ProseMirror) {
  min-height: 300px;
  padding: 16px;
  outline: none;
}

.editor-container :deep(.ProseMirror p) {
  margin: 8px 0;
}

.editor-container :deep(.ProseMirror blockquote) {
  border-left: 4px solid #ed8f23;
  padding-left: 16px;
  margin: 16px 0;
  font-style: italic;
  color: #666;
}

.editor-container :deep(.ProseMirror hr) {
  border: none;
  border-top: 2px solid #e0e0e0;
  margin: 24px 0;
}

.editor-container :deep(.ProseMirror pre) {
  background: #f5f5f5;
  border-radius: 6px;
  padding: 16px;
  overflow-x: auto;
  font-family: 'Courier New', monospace;
  font-size: 14px;
  line-height: 1.6;
}

.editor-container :deep(.ProseMirror code) {
  background: #f5f5f5;
  padding: 2px 6px;
  border-radius: 3px;
  font-family: 'Courier New', monospace;
  font-size: 14px;
}

.editor-container :deep(.ProseMirror a) {
  color: #ed8f23;
  text-decoration: underline;
  cursor: pointer;
}

.editor-container :deep(.ProseMirror a:hover) {
  color: #d87f1f;
}

.form-actions {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  margin-top: 24px;
  padding-top: 24px;
  border-top: 1px solid #e8e8e8;
}

/* 动画效果 */
@keyframes fadeInOverlay {
  from {
    background-color: rgba(0, 0, 0, 0);
    opacity: 0;
  }
  to {
    background-color: rgba(0, 0, 0, 0.5);
    opacity: 1;
  }
}

@keyframes fadeInOverlayWithBlur {
  from {
    background-color: rgba(0, 0, 0, 0);
    opacity: 0;
    backdrop-filter: blur(0px);
  }
  to {
    background-color: rgba(0, 0, 0, 0.5);
    opacity: 1;
    backdrop-filter: blur(5px);
  }
}

@keyframes fadeOutOverlayWithBlur {
  from {
    background-color: rgba(0, 0, 0, 0.5);
    opacity: 1;
    backdrop-filter: blur(5px);
  }
  to {
    background-color: rgba(0, 0, 0, 0);
    opacity: 0;
    backdrop-filter: blur(0px);
  }
}

@keyframes slideInFromTop {
  from {
    transform: translateY(-100px);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}

@keyframes slideOutToTop {
  from {
    transform: translateY(0);
    opacity: 1;
  }
  to {
    transform: translateY(-100px);
    opacity: 0;
  }
}
</style>