<template>
  <div class="auth-modal-overlay" v-if="show" :class="{ 'show': true, 'hiding': isClosing }" @click.self="handleClose">
    <div class="auth-modal" :class="{ 'closing': isClosing }">
      <div class="auth-header">
        <button class="auth-close" @click="handleClose">
          <img src="@/assets/close.png" class="close-icon" alt="关闭" />
        </button>
      </div>

      <div class="auth-content">
        <div class="auth-tabs">
          <button
            class="auth-tab"
            :class="{ active: mode === 'login' }"
            @click="mode = 'login'"
          >
            登录
          </button>
          <button
            class="auth-tab"
            :class="{ active: mode === 'register' }"
            @click="mode = 'register'"
          >
            注册
          </button>
        </div>

        <form class="auth-form" @submit.prevent="handleSubmit">
          <div class="form-group">
            <label>用户名</label>
            <input
              v-model="username"
              type="text"
              placeholder="请输入用户名"
              required
            />
          </div>

          <div class="form-group">
            <label>密码</label>
            <input
              v-model="password"
              type="password"
              placeholder="请输入密码"
              required
            />
          </div>

          <!-- Cloudflare人机验证预留位置 -->
          <div class="cf-turnstile-container">
            <!-- 这里预留Cloudflare Turnstile组件的位置 -->
            <!-- <div class="cf-turnstile" data-sitekey="your-site-key"></div> -->
          </div>

          <HSRButton size="default" :tag="null" type="submit" :loading="loading" class="auth-submit">
            {{ mode === 'login' ? '登录' : '注册' }}
          </HSRButton>
        </form>

        <div class="auth-error" v-if="error">{{ error }}</div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { ElMessage } from 'element-plus';
import { authAPI } from '../services/api';
import { sanitizeUsername } from '../utils/security';
import HSRButton from './HSRButton.vue';

const props = defineProps({
  show: {
    type: Boolean,
    default: false
  }
});

const emit = defineEmits(['close', 'success']);

const mode = ref('login'); // 'login' 或 'register'
const isClosing = ref(false); // 关闭动画状态
const username = ref('');
const password = ref('');
const loading = ref(false);
const error = ref('');

const handleSubmit = async () => {
  error.value = '';
  loading.value = true;

  try {
    // 过滤用户名，移除危险字符
    const sanitizedUsername = sanitizeUsername(username.value);

    let result;
    if (mode.value === 'login') {
      result = await authAPI.login(sanitizedUsername, password.value);

      // 保存token和用户信息
      localStorage.setItem('token', result.token);
      localStorage.setItem('user', JSON.stringify({ username: result.username }));

      // 触发成功事件
      emit('success', { username: result.username });
    } else {
      result = await authAPI.register(sanitizedUsername, password.value);

      // 注册成功，显示用户名
      console.log('注册成功:', result.username);
      ElMessage.success(`注册成功！用户名: ${result.username}`);

      // 切换到登录模式
      mode.value = 'login';
      password.value = '';
      return; // 不关闭模态框，让用户登录
    }

    // 关闭模态框
    handleClose();
  } catch (err) {
    error.value = err.message || (mode.value === 'login' ? '登录失败' : '注册失败');
  } finally {
    loading.value = false;
  }
};

// 关闭模态框（带动画）
const handleClose = () => {
  isClosing.value = true;
  setTimeout(() => {
    emit('close');
    isClosing.value = false;
  }, 250); // 与CSS动画时长一致
};
</script>

<style scoped>
.auth-modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2000;
  backdrop-filter: blur(0px);
  opacity: 0;
  animation: fadeInOverlay 0.2s ease-out forwards;
}

.auth-modal-overlay.show {
  background-color: rgba(0, 0, 0, 0.5);
  opacity: 1;
  backdrop-filter: blur(5px);
  animation: fadeInOverlayWithBlur 0.2s ease-out forwards;
}

.auth-modal-overlay.closing {
  animation: fadeOutOverlayWithBlur 0.2s ease-in forwards;
}

.auth-modal-overlay.hiding {
  animation: fadeOutOverlayWithBlur 0.25s ease-in forwards;
}

.auth-modal {
  width: 400px;
  max-width: 90%;
  background-color: white;
  border-radius: 10px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
  display: flex;
  flex-direction: column;
  transform: translateY(-100px);
  opacity: 0;
  overflow: hidden;
  position: relative;
  animation: slideInFromTop 0.3s cubic-bezier(0.16, 0.8, 0.37, 0.99) forwards;
}

.auth-modal.closing {
  animation: slideOutToTop 0.25s cubic-bezier(0.16, 0.8, 0.37, 0.99) forwards;
}

.auth-modal.closing {
  animation: slideOutToTop 0.25s cubic-bezier(0.16, 0.8, 0.37, 0.99) forwards;
}

.auth-header {
  display: flex;
  justify-content: flex-end;
  padding: 15px 20px 10px;
}

.auth-content {
  padding: 0 30px 30px;
}

.auth-close {
  background: none;
  border: none;
  cursor: pointer;
  width: 30px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  transition: background-color 0.2s;
  padding: 0;
}

.auth-close:hover {
  background-color: #f0f0f0;
}

.close-icon {
  width: 16px;
  height: 16px;
  object-fit: contain;
}

.auth-tabs {
  display: flex;
  gap: 10px;
  margin-bottom: 25px;
  border-bottom: 2px solid #e8e8e8;
}

.auth-tab {
  flex: 1;
  padding: 12px;
  border: none;
  background: none;
  cursor: pointer;
  font-size: 16px;
  color: #666;
  transition: all 0.2s;
  border-bottom: 2px solid transparent;
  margin-bottom: -2px;
}

.auth-tab.active {
  color: #ed8f23;
  border-bottom-color: #ed8f23;
  font-weight: 600;
}

.auth-form {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.form-group label {
  font-size: 14px;
  color: #333;
  font-weight: 500;
}

.form-group input {
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 14px;
  transition: border-color 0.2s;
}

.form-group input:focus {
  outline: none;
  border-color: #ed8f23;
}

.cf-turnstile-container {
  min-height: 65px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f9f9f9;
  border: 1px dashed #ddd;
  border-radius: 6px;
  color: #999;
  font-size: 12px;
}

.auth-submit {
  padding: 12px;
  background: #ed8f23;
  color: white;
  border: none;
  border-radius: 6px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: background-color 0.2s;
}

.auth-submit:hover:not(:disabled) {
  background: #d87f1f;
}

.auth-submit:disabled {
  background: #ccc;
  cursor: not-allowed;
}

.auth-error {
  color: #ff4444;
  font-size: 14px;
  text-align: center;
  margin-top: 10px;
}

/* 动画效果 */
@keyframes fadeInOverlay {
  from {
    background-color: rgba(0, 0, 0, 0);
    opacity: 0;
  }

  to {
    background-color: rgba(0, 0, 0, 0.5);
    opacity: 1;
  }
}

@keyframes fadeInOverlayWithBlur {
  from {
    background-color: rgba(0, 0, 0, 0);
    opacity: 0;
    backdrop-filter: blur(0px);
  }

  to {
    background-color: rgba(0, 0, 0, 0.5);
    opacity: 1;
    backdrop-filter: blur(5px);
  }
}

@keyframes fadeOutOverlayWithBlur {
  from {
    background-color: rgba(0, 0, 0, 0.5);
    opacity: 1;
    backdrop-filter: blur(5px);
  }

  to {
    background-color: rgba(0, 0, 0, 0);
    opacity: 0;
    backdrop-filter: blur(0px);
  }
}

@keyframes slideInFromTop {
  from {
    transform: translateY(-100px);
    opacity: 0;
  }

  to {
    transform: translateY(0);
    opacity: 1;
  }
}

@keyframes slideOutToTop {
  from {
    transform: translateY(0);
    opacity: 1;
  }

  to {
    transform: translateY(-100px);
    opacity: 0;
  }
}
</style>