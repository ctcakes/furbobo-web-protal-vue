<template>
  <div class="hsr-input-wrapper" :class="{ 'is-focused': isFocused }">
    <textarea
      v-if="type === 'textarea'"
      :value="modelValue"
      @input="handleInput"
      @focus="handleFocus"
      @blur="handleBlur"
      :placeholder="placeholder"
      :rows="rows"
      :disabled="disabled"
      :readonly="readonly"
      class="hsr-input hsr-textarea"
      :style="{ aspectRatio }"
    ></textarea>
    <input
      v-else
      :type="type"
      :value="modelValue"
      @input="handleInput"
      @focus="handleFocus"
      @blur="handleBlur"
      :placeholder="placeholder"
      :disabled="disabled"
      :readonly="readonly"
      class="hsr-input"
      :style="{ aspectRatio }"
    />
  </div>
</template>

<script setup>
import { ref } from 'vue'

const props = defineProps({
  modelValue: {
    type: [String, Number],
    default: ''
  },
  type: {
    type: String,
    default: 'text'
  },
  placeholder: {
    type: String,
    default: ''
  },
  disabled: {
    type: Boolean,
    default: false
  },
  readonly: {
    type: Boolean,
    default: false
  },
  rows: {
    type: Number,
    default: 3
  },
  aspectRatio: {
    type: String,
    default: '16/9'
  }
})

const emit = defineEmits(['update:modelValue', 'focus', 'blur'])

const isFocused = ref(false)

const handleInput = (event) => {
  emit('update:modelValue', event.target.value)
}

const handleFocus = (event) => {
  isFocused.value = true
  emit('focus', event)
}

const handleBlur = (event) => {
  isFocused.value = false
  emit('blur', event)
}
</script>

<style scoped>
.hsr-input-wrapper {
  position: relative;
  width: 100%;
}

.hsr-input {
  width: 100%;
  height: 32px;
  padding: 6px 10px;
  font-size: 14px;
  font-family: 'ZhCnFont', sans-serif;
  color: #000000;
  background-color: rgba(209, 209, 209, 0.7);
  border: 1px solid #909090;
  border-radius: 0;
  outline: none;
  transition: all 0.2s ease;
  box-sizing: border-box;
  line-height: 1.2;
}

/* 文本选中背景色 */
.hsr-input::selection,
.hsr-textarea::selection {
  background-color: #9c9c9c;
  color: #000000;
}

.hsr-input::placeholder {
  color: #666;
}

/* hover 只改填充色 */
.hsr-input:hover {
  background-color: rgba(76, 76, 76, 0.1);
  /* 其他属性保持不变 */
}

/* 聚焦状态：边框颜色变化 */
.hsr-input-wrapper.is-focused .hsr-input {
  border-color: #4c4c4c;
  background-color: rgba(76, 76, 76, 0.1);
  color: #000;
}

/* 禁用状态 */
.hsr-input:disabled {
  background-color: #e0e0e0;
  cursor: not-allowed;
  opacity: 0.6;
}

.hsr-input:disabled:hover {
  background-color: #e0e0e0;
}

/* 只读状态 */
.hsr-input:readonly {
  background-color: #f5f5f5;
  cursor: default;
}

/* textarea 特殊样式 */
.hsr-textarea {
  resize: none;
  aspect-ratio: auto;
  min-height: 80px;
}

/* 覆盖文章评论输入框的样式 */
.article-comment-input .hsr-input {
  min-height: 80px;
  aspect-ratio: auto;
}

/* 覆盖回复模态框输入框的样式 */
.reply-modal-body .hsr-input {
  min-height: 120px;
  aspect-ratio: auto;
}
</style>