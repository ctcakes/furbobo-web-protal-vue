<template>
  <div v-if="show" class="avatar-modal-overlay" :class="{ 'show': true, 'hiding': isClosing }">
    <div class="avatar-modal" :class="{ 'closing': isClosing }">
      <div class="avatar-modal-header">
        <span class="avatar-modal-title">选择头像</span>
        <button class="avatar-modal-close" @click="handleClose" :disabled="isUpdatingAvatar">
          <img src="@/assets/close.png" class="close-icon" alt="关闭" />
        </button>
      </div>

      <div class="avatar-modal-content">
        <!-- 当前头像展示 -->
        <div class="avatar-section-title">当前头像</div>
        <div class="current-avatar-display">
          <img v-if="currentUser?.avatar_url" :src="currentUser.avatar_url" class="current-avatar" alt="当前头像" />
          <div v-else class="current-avatar-placeholder">暂无头像</div>
        </div>

        <div class="avatar-section-title">预设头像</div>
        <div class="avatar-grid">
          <div v-for="(avatar, index) in presetAvatars" :key="index" class="avatar-item"
            :class="{ 'avatar-selected': currentUser?.avatar_url === avatar, 'is-loading': isUpdatingAvatar }"
            @click="updateAvatar(avatar)">
            <img :src="avatar" class="avatar-preview" />
            <div v-if="currentUser?.avatar_url === avatar" class="avatar-check">
              <span class="check-icon">✓</span>
            </div>
            <div v-if="isUpdatingAvatar" class="avatar-loading-overlay">
              <span class="loading-icon">⟳</span>
            </div>
          </div>
        </div>

        <div class="avatar-section-title">上传头像</div>
        <div class="avatar-upload-section">
          <HSRButton size="small" :tag="null" :custom-icon-svg="uploadIconSvg" :icon-size="16" @click.prevent="triggerFileUpload">选择图片上传</HSRButton>
          <div class="upload-tip">支持 JPG、PNG 格式，建议尺寸 200x200px</div>
        </div>

        <!-- 自定义头像预览 -->
        <div v-if="customAvatarPreview" class="custom-avatar-preview">
          <div class="avatar-section-title">预览</div>
          <img :src="customAvatarPreview" class="avatar-preview-large" />
          <HSRButton size="small" :tag="null" :custom-icon-svg="confirmIconSvg" :icon-size="16" :loading="uploading"
            @click="confirmCustomAvatarUpload">
            确认上传
          </HSRButton>
          <HSRButton size="small" :tag="null" :custom-icon-svg="cancelIconSvg" :icon-size="18"
            @click="cancelCustomAvatar">
            取消</HSRButton>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, watch } from 'vue';
import HSRButton from './HSRButton.vue';
import { ElMessage } from 'element-plus';

const props = defineProps({
  show: {
    type: Boolean,
    default: false
  },
  currentUser: {
    type: Object,
    default: null
  },
  presetAvatars: {
    type: Array,
    default: () => []
  }
});

const emit = defineEmits(['close', 'updateAvatar', 'uploadAvatar']);

const isClosing = ref(false);
const isUpdatingAvatar = ref(false);
const uploading = ref(false);
const customAvatarPreview = ref('');

const uploadIconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024"><path fill="currentColor" d="M160 832h704a32 32 0 1 1 0 64H160a32 32 0 0 1 0-64m384-578.304V704h-64V247.296L237.248 490.048 192 444.8 508.8 128l316.8 316.8-45.312 45.248z"></path></svg>`;

const confirmIconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024"><path fill="currentColor" d="M77.248 415.04a64 64 0 0 1 90.496 0l226.304 226.304L846.528 188.8a64 64 0 1 1 90.56 90.496l-543.04 543.04-316.8-316.8a64 64 0 0 1 0-90.496"></path></svg>`;

const cancelIconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024"><path fill="currentColor" d="M195.2 195.2a64 64 0 0 1 90.496 0L512 421.504 738.304 195.2a64 64 0 0 1 90.496 90.496L602.496 512 828.8 738.304a64 64 0 0 1-90.496 90.496L512 602.496 285.696 828.8a64 64 0 0 1-90.496-90.496L421.504 512 195.2 285.696a64 64 0 0 1 0-90.496"></path></svg>`;

// 触发文件上传
const triggerFileUpload = () => {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'image/*';
  input.onchange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        customAvatarPreview.value = e.target.result;
      };
      reader.readAsDataURL(file);
    }
  };
  input.click();
};

// 确认上传自定义头像
const confirmCustomAvatarUpload = () => {
  if (customAvatarPreview.value) {
    emit('uploadAvatar', customAvatarPreview.value);
    customAvatarPreview.value = '';
  }
};

// 取消自定义头像
const cancelCustomAvatar = () => {
  customAvatarPreview.value = '';
};

// 更新头像
const updateAvatar = async (avatarUrl) => {
  if (isUpdatingAvatar.value) return;

  isUpdatingAvatar.value = true;

  try {
    emit('updateAvatar', avatarUrl);
  } catch (error) {
    ElMessage.error('头像更新失败');
    console.error('更新头像失败:', error);
  } finally {
    isUpdatingAvatar.value = false;
  }
};

// 关闭模态框
const handleClose = () => {
  isClosing.value = true;
  setTimeout(() => {
    emit('close');
    isClosing.value = false;
    customAvatarPreview.value = '';
  }, 250);
};
</script>

<style scoped>
.avatar-modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2000;
  backdrop-filter: blur(0px);
  opacity: 0;
  animation: fadeInOverlay 0.2s ease-out forwards;
}

.avatar-modal-overlay.show {
  background-color: rgba(0, 0, 0, 0.5);
  opacity: 1;
  backdrop-filter: blur(5px);
  animation: fadeInOverlayWithBlur 0.2s ease-out forwards;
}

.avatar-modal-overlay.closing {
  animation: fadeOutOverlayWithBlur 0.2s ease-in forwards;
}

.avatar-modal {
  width: 600px;
  max-width: 90%;
  max-height: 80vh;
  background-color: white;
  border-radius: 10px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
  display: flex;
  flex-direction: column;
  transform: translateY(-100px);
  opacity: 0;
  overflow: hidden;
  position: relative;
  animation: slideInFromTop 0.3s cubic-bezier(0.16, 0.8, 0.37, 0.99) forwards;
}

.avatar-modal.closing {
  animation: slideOutToTop 0.25s cubic-bezier(0.16, 0.8, 0.37, 0.99) forwards;
}

.avatar-modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px 24px;
  border-bottom: 1px solid #e8e8e8;
  background: #fafafa;
}

.avatar-modal-title {
  font-size: 18px;
  font-weight: 600;
  color: #333;
  margin: 0;
}

.avatar-modal-close {
  background: none;
  border: none;
  cursor: pointer;
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  transition: background-color 0.2s;
  padding: 0;
}

.avatar-modal-close:hover:not(:disabled) {
  background-color: #e0e0e0;
}

.avatar-modal-close:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}

.close-icon {
  width: 18px;
  height: 18px;
  object-fit: contain;
}

.avatar-modal-content {
  padding: 24px;
  overflow-y: auto;
}

.avatar-section-title {
  font-size: 16px;
  font-weight: 600;
  color: #333;
  margin: 24px 0 12px;
}

.avatar-section-title:first-child {
  margin-top: 0;
}

.current-avatar-display {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 20px;
  background: rgba(0, 0, 0, 0.05);
  border-radius: 8px;
  margin-bottom: 12px;
}

.current-avatar {
  width: 100px;
  height: 100px;
  border-radius: 50%;
  object-fit: cover;
  border: 3px solid #ed8f23;
}

.current-avatar-placeholder {
  width: 100px;
  height: 100px;
  border-radius: 50%;
  background: #ccc;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #666;
  font-size: 14px;
}

.avatar-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
  padding: 0;
}

.avatar-item {
  position: relative;
  width: 100%;
  aspect-ratio: 1;
  border-radius: 50%;
  overflow: hidden;
  cursor: pointer;
  border: 3px solid transparent;
  transition: all 0.3s ease;
}

.avatar-item:hover {
  border-color: #ffffff;
  box-shadow: 0 0 12px rgba(255, 255, 255, 0.8);
}

.avatar-item.is-loading {
  cursor: not-allowed;
  opacity: 0.7;
}

.avatar-item.is-loading:hover {
  border-color: transparent;
  box-shadow: none;
}

.avatar-item.avatar-selected {
  border-color: #ed8f23;
}

.avatar-preview {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.avatar-check {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 32px;
  height: 32px;
  background: #ed8f23;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  animation: scaleIn 0.2s ease-out;
}

.check-icon {
  color: white;
  font-size: 18px;
  font-weight: bold;
}

@keyframes scaleIn {
  from {
    transform: translate(-50%, -50%) scale(0);
  }
  to {
    transform: translate(-50%, -50%) scale(1);
  }
}

.avatar-loading-overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
}

.loading-icon {
  font-size: 24px;
  color: white;
  animation: rotate 1s linear infinite;
}

@keyframes rotate {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}

.avatar-upload-section {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.upload-tip {
  font-size: 12px;
  color: #999;
}

.custom-avatar-preview {
  margin-top: 24px;
  padding: 16px;
  background: rgba(0, 0, 0, 0.03);
  border-radius: 8px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 16px;
}

.avatar-preview-large {
  width: 120px;
  height: 120px;
  border-radius: 50%;
  object-fit: cover;
  border: 3px solid #ed8f23;
}

/* 动画效果 */
@keyframes fadeInOverlay {
  from {
    background-color: rgba(0, 0, 0, 0);
    opacity: 0;
  }

  to {
    background-color: rgba(0, 0, 0, 0.5);
    opacity: 1;
  }
}

@keyframes fadeInOverlayWithBlur {
  from {
    background-color: rgba(0, 0, 0, 0);
    opacity: 0;
    backdrop-filter: blur(0px);
  }

  to {
    background-color: rgba(0, 0, 0, 0.5);
    opacity: 1;
    backdrop-filter: blur(5px);
  }
}

@keyframes fadeOutOverlayWithBlur {
  from {
    background-color: rgba(0, 0, 0, 0.5);
    opacity: 1;
    backdrop-filter: blur(5px);
  }

  to {
    background-color: rgba(0, 0, 0, 0);
    opacity: 0;
    backdrop-filter: blur(0px);
  }
}

@keyframes slideInFromTop {
  from {
    transform: translateY(-100px);
    opacity: 0;
  }

  to {
    transform: translateY(0);
    opacity: 1;
  }
}

@keyframes slideOutToTop {
  from {
    transform: translateY(0);
    opacity: 1;
  }

  to {
    transform: translateY(-100px);
    opacity:  AvatarModal.vue (创建文件，完成写入新内容)
 0;
  }
}
</style>