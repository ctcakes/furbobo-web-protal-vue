<template>
  <div v-if="show" class="input-modal-overlay" :class="{ 'show': true, 'hiding': isClosing }">
    <div class="input-modal" :class="{ 'closing': isClosing }">
      <div class="input-modal-header">
        <h3 class="input-modal-title">{{ title }}</h3>
        <button class="input-modal-close" @click="handleCancel">
          <img src="@/assets/close.png" class="close-icon" alt="关闭" />
        </button>
      </div>

      <div class="input-modal-body">
        <div class="input-field">
          <label>{{ label }}</label>
          <input
            v-model="inputValue"
            type="text"
            :placeholder="placeholder"
            @keydown.enter="handleConfirm"
            ref="inputRef"
          />
          <div v-if="errorMessage" class="error-message">{{ errorMessage }}</div>
        </div>
      </div>

      <div class="input-modal-footer">
        <HSRButton size="small" :tag="null" :custom-icon-svg="cancelIconSvg" :icon-size="16" @click="handleCancel">
          取消
        </HSRButton>
        <HSRButton size="small" :tag="null" :custom-icon-svg="confirmIconSvg" :icon-size="16" @click="handleConfirm" :disabled="!inputValue.trim()">
          确定
        </HSRButton>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, watch, nextTick } from 'vue';
import HSRButton from './HSRButton.vue';

const props = defineProps({
  show: {
    type: Boolean,
    default: false
  },
  title: {
    type: String,
    default: '输入'
  },
  label: {
    type: String,
    default: ''
  },
  placeholder: {
    type: String,
    default: ''
  },
  defaultValue: {
    type: String,
    default: ''
  }
});

const emit = defineEmits(['confirm', 'cancel', 'close']);

const isClosing = ref(false);
const inputValue = ref(props.defaultValue);
const errorMessage = ref('');
const inputRef = ref(null);

const cancelIconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024"><path fill="currentColor" d="M195.2 195.2a64 64 0 0 1 90.496 0L512 421.504 738.304 195.2a64 64 0 0 1 90.496 90.496L602.496 512 828.8 738.304a64 64 0 0 1-90.496 90.496L512 602.496 285.696 828.8a64 64 0 0 1-90.496-90.496L421.504 512 195.2 285.696a64 64 0 0 1 0-90.496"></path></svg>`;

const confirmIconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024"><path fill="currentColor" d="M77.248 415.04a64 64 0 0 1 90.496 0l226.304 226.304L846.528 188.8a64 64 0 1 1 90.56 90.496l-543.04 543.04-316.8-316.8a64 64 0 0 1 0-90.496"></path></svg>`;

// 监听显示状态
watch(() => props.show, (newVal) => {
  if (newVal) {
    inputValue.value = props.defaultValue;
    errorMessage.value = '';
    isClosing.value = false;
    nextTick(() => {
      if (inputRef.value) {
        inputRef.value.focus();
      }
    });
  }
});

const handleConfirm = () => {
  if (!inputValue.value.trim()) {
    errorMessage.value = '请输入内容';
    return;
  }
  
  // 验证链接格式
  if (props.title === '添加链接') {
    const urlPattern = /^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/;
    if (!urlPattern.test(inputValue.value)) {
      errorMessage.value = '请输入有效的链接地址';
      return;
    }
  }
  
  emit('confirm', inputValue.value);
  handleClose();
};

const handleCancel = () => {
  emit('cancel');
  handleClose();
};

const handleClose = () => {
  isClosing.value = true;
  // 等待动画完成后发出关闭事件
  setTimeout(() => {
    inputValue.value = '';
    errorMessage.value = '';
    emit('close');
  }, 250);
};
</script>

<style scoped>
.input-modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 3000;
  backdrop-filter: blur(0px);
  opacity: 0;
  animation: fadeInOverlay 0.2s ease-out forwards;
}

.input-modal-overlay.show {
  background-color: rgba(0, 0, 0, 0.5);
  opacity: 1;
  backdrop-filter: blur(5px);
  animation: fadeInOverlayWithBlur 0.2s ease-out forwards;
}

.input-modal-overlay.closing {
  animation: fadeOutOverlayWithBlur 0.2s ease-in forwards;
}

.input-modal {
  width: 450px;
  max-width: 90%;
  background-color: white;
  border-radius: 10px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
  display: flex;
  flex-direction: column;
  transform: translateY(-100px);
  opacity: 0;
  overflow: hidden;
  position: relative;
  animation: slideInFromTop 0.3s cubic-bezier(0.16, 0.8, 0.37, 0.99) forwards;
}

.input-modal.closing {
  animation: slideOutToTop 0.25s cubic-bezier(0.16, 0.8, 0.37, 0.99) forwards;
}

.input-modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px 24px;
  border-bottom: 1px solid #e8e8e8;
  background: #fafafa;
}

.input-modal-title {
  font-size: 18px;
  font-weight: 600;
  color: #333;
  margin: 0;
}

.input-modal-close {
  background: none;
  border: none;
  cursor: pointer;
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  transition: background-color 0.2s;
  padding: 0;
}

.input-modal-close:hover {
  background-color: #e0e0e0;
}

.close-icon {
  width: 18px;
  height: 18px;
  object-fit: contain;
}

.input-modal-body {
  padding: 24px;
}

.input-field {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.input-field label {
  font-size: 14px;
  font-weight: 600;
  color: #333;
}

.input-field input {
  padding: 12px 16px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 14px;
  transition: border-color 0.2s;
  outline: none;
}

.input-field input:focus {
  outline: none;
  border-color: #ed8f23;
}

.input-field input:focus {
  outline: none;
}

.error-message {
  font-size: 13px;
  color: #ff4d4f;
}

.input-modal-footer {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  padding: 16px 24px;
  border-top: 1px solid #e8e8e8;
  background: #fafafa;
}

/* 动画效果 */
@keyframes fadeInOverlay {
  from {
    background-color: rgba(0, 0, 0, 0);
    opacity: 0;
  }

  to {
    background-color: rgba(0, 0, 0, 0.5);
    opacity: 1;
  }
}

@keyframes fadeInOverlayWithBlur {
  from {
    background-color: rgba(0, 0, 0, 0);
    opacity: 0;
    backdrop-filter: blur(0px);
  }

  to {
    background-color: rgba(0, 0, 0, 0.5);
    opacity: 1;
    backdrop-filter: blur(5px);
  }
}

@keyframes fadeOutOverlayWithBlur {
  from {
    background-color: rgba(0, 0, 0, 0.5);
    opacity: 1;
    backdrop-filter: blur(5px);
  }

  to {
    background-color: rgba(0, 0, 0, 0);
    opacity: 0;
    backdrop-filter: blur(0px);
  }
}

@keyframes slideInFromTop {
  from {
    transform: translateY(-100px);
    opacity: 0;
  }

  to {
    transform: translateY(0);
    opacity: 1;
  }
}

@keyframes slideOutToTop {
  from {
    transform: translateY(0);
    opacity: 1;
  }

  to {
    transform: translateY(-100px);
    opacity: 0;
  }
}
</style>