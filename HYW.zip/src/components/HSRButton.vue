<template>
  <button
    :class="['sr-action-btn', sizeClass, { 'is-disabled': disabled || loading, 'is-active': active, 'sr-action-btn--no-tag': !tag, 'sr-action-btn--custom-icon': customIcon || customIconSvg, 'is-loading': loading }]"
    :disabled="disabled || loading"
    @click="handleClick"
  >
    <!-- 加载状态：旋转圆圈 -->
    <span v-if="loading" class="sr-icon-loading">
      <svg class="loading-circle" viewBox="0 0 50 50">
        <circle class="loading-path" cx="25" cy="25" r="20" fill="none" stroke="currentColor" stroke-width="5"></circle>
      </svg>
    </span>
    <!-- SVG 图标 -->
    <span v-else-if="customIconSvg" class="sr-icon-custom" :style="iconStyle" v-html="customIconSvg"></span>
    <!-- 图片图标 -->
    <span v-else-if="customIcon" class="sr-icon-custom" :style="iconStyle">
      <img :src="customIcon" alt="icon" />
    </span>
    <!-- 默认菱形图标 -->
    <span v-else class="sr-icon-diamond"></span>
    <span class="sr-text">
      <span v-if="tag" class="sr-tag">{{ tag }}</span>
      <slot>{{ loading ? '' : text }}</slot>
    </span>
  </button>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  tag: {
    type: String,
    default: '【回复】'
  },
  text: {
    type: String,
    default: ''
  },
  size: {
    type: String,
    default: 'default',
    validator: (value) => ['large', 'default', 'small'].includes(value)
  },
  disabled: {
    type: Boolean,
    default: false
  },
  active: {
    type: Boolean,
    default: false
  },
  customIcon: {
    type: String,
    default: ''
  },
  customIconSvg: {
    type: String,
    default: ''
  },
  iconSize: {
    type: Number,
    default: null
  },
  loading: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits(['click'])

const sizeClass = computed(() => {
  return props.size !== 'default' ? `sr-action-btn--${props.size}` : ''
})

const iconStyle = computed(() => {
  const style = {}
  if (props.iconSize) {
    style.width = `${props.iconSize}px`
    style.height = `${props.iconSize}px`
  }
  return style
})

const handleClick = (event) => {
  if (!props.disabled && !props.loading) {
    emit('click', event)
  }
}
</script>

<style scoped>
/* 加载图标容器 */
.sr-icon-loading {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  margin-right: 16px;
  flex-shrink: 0;
  width: 16px;
  height: 16px;
}

.loading-circle {
  width: 100%;
  height: 100%;
  animation: spin 1s linear infinite;
}

.loading-path {
  stroke: #ed8f23;
  stroke-linecap: round;
  stroke-dasharray: 90, 150;
  stroke-dashoffset: 0;
  animation: dash 1.5s ease-in-out infinite;
}

@keyframes spin {
  100% {
    transform: rotate(360deg);
  }
}

@keyframes dash {
  0% {
    stroke-dasharray: 1, 150;
    stroke-dashoffset: 0;
  }
  50% {
    stroke-dasharray: 90, 150;
    stroke-dashoffset: -35;
  }
  100% {
    stroke-dasharray: 90, 150;
    stroke-dashoffset: -124;
  }
}

/* 自定义图标容器 */
.sr-icon-custom {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  margin-right: 16px;
  flex-shrink: 0;
  width: 16px;
  height: 16px;
}

.sr-icon-custom svg {
  width: 100%;
  height: 100%;
  color: #000000;
  transition: color 0.3s ease;
}

.sr-icon-custom img {
  width: 100%;
  height: 100%;
  object-fit: contain;
}

/* 自定义图标在悬停时的效果 */
.sr-action-btn:hover .sr-icon-custom svg {
  color: #000000;
}

.sr-action-btn:hover .sr-icon-custom img {
  filter: invert(1);
}

/* 自定义图标在禁用状态时保持原样 */
.sr-action-btn.is-disabled:hover .sr-icon-custom svg {
  color: #000000;
}

.sr-action-btn.is-disabled:hover .sr-icon-custom img {
  filter: none;
}

/* 自定义图标在激活状态时的效果 */
.sr-action-btn.is-active:hover .sr-icon-custom svg {
  color: #000000;
}

.sr-action-btn.is-active:hover .sr-icon-custom img {
  filter: none;
}

/* 不同尺寸的自定义图标 - 当没有设置 iconSize 时生效 */
.sr-action-btn--small .sr-icon-custom:not([style*="width"]) {
  width: 16px;
  height: 16px;
  margin-right: 12px;
}

.sr-action-btn--large .sr-icon-custom:not([style*="width"]) {
  width: 20px;
  height: 20px;
  margin-right: 20px;
}

/* 不同尺寸的加载图标 */
.sr-action-btn--small .sr-icon-loading {
  width: 14px;
  height: 14px;
  margin-right: 10px;
}

.sr-action-btn--large .sr-icon-loading {
  width: 18px;
  height: 18px;
  margin-right: 18px;
}
</style>