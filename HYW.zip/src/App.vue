<template>
  <!-- 预加载页面 -->
  <div v-if="showPreloader" class="preloader">
    <div class="preloader-bg-animation">
      <div class="circle circle-blue"></div>
      <div class="circle circle-orange"></div>
    </div>
    <div class="loading-logo">
      <img src="@/assets/logo.png" class="raw-image" style="width: 150px !important;height: 150px !important;" />
    </div>
    <div class="loading-spinner">
      <svg class="loading-circle" viewBox="0 0 50 50">
        <circle class="loading-path" cx="25" cy="25" r="20" fill="none" stroke="currentColor" stroke-width="5"></circle>
      </svg>
    </div>
    <div class="loading-text">资源加载中... {{ loadingProgress }}%</div>
  </div>

  <!-- 主要内容 -->
  <div v-else class="screen-wrapper">
    <div class="tablet-viewport" ref="tabletRef">

      <!-- <div class="exm-overlay">
        <img src="@/assets/exm.jpeg" class="raw-image exm-opacity" />
      </div> -->

      <div class="fixed-header animate__animated animate__fadeIn">
        <img src="@/assets/monkey.png" class="raw-image" style="height: 67px !important;width: 70px !important;" />
        <div class="header-text">
          <div class="line-top">狸狸通信</div>
          <div class="line-bottom">狸狸门户网</div>
        </div>
      </div>

      <div class="bg-sidebar" :class="{ 'is-shrunk': isShrunk }">
        <div class="bg-w-overlay"></div>

        <div class="sidebar-content" :class="{ 'content-visible': showSidebarContent }">
          <div class="center-part">
            <img src="@/assets/logo.png" class="raw-image side-logo-margin" />
            <div class="qipao-container">
              <img src="@/assets/qipao.png" class="raw-image" style="height: 80px !important;" />
              <div class="qipao-text-area"></div>
            </div>
          </div>

          <div class="user-actions-container">
            <div class="sponsor-label">
              <span class="dot"></span> 赞助方 <span class="dot"></span>
            </div>
            <div class="icon-group">
              <div class="svg-btn" v-for="n in 3" :key="n">
                <svg viewBox="0 0 24 24" width="20" height="20">
                  <rect width="24" height="24" fill="currentColor" rx="4" />
                </svg>
              </div>
            </div>
            <HSRButton size="small" :tag="null" :custom-icon-svg="userIconSvg" :icon-size="20" class="sidebar-login-btn"
              @click="handleUsernameClick">
              {{ currentUser ? currentUser.username : '登录/注册' }}
            </HSRButton>
            
            <!-- 已登录用户操作按钮 -->
            <div v-if="currentUser" class="user-actions-buttons">
              <HSRButton size="small" :tag="null" class="user-action-btn" @click="openAvatarSettings">
                头像设置
              </HSRButton>
              <HSRButton size="small" :tag="null" class="user-action-btn logout-btn" @click="handleLogout">
                退出登录
              </HSRButton>
            </div>
          </div>
        </div>
      </div>

      <div v-if="showCenterLogo" class="center-logo-wrapper">
        <img src="@/assets/logo.png" class="raw-image main-logo-anim" @animationend="onAnimationEnd" />
      </div>

      <!-- 右侧内容区域 -->
      <div class="right-content-area" :class="{ 'content-visible': showRightContent }">
        <!-- 顶部固定条 -->
        <div class="top-fixed-bar">
          <div class="top-row">
            <div class="ctcake-text">CTCAKE</div>
            <div class="line"></div>
          </div>

          <div class="bottom-row">
            <div class="back-button">
              <img src="@/assets/back.png" class="back-icon" />
            </div>
          </div>
        </div>


        <!-- 右侧状态栏 - 橙色滚动条 -->
        <div class="right-status-bar">
          <div class="scroll-indicator"></div>
        </div>

        <!-- 内容容器，支持滚动 -->
        <div class="content-container" @scroll="updateScrollIndicator">
          <!-- 发帖按钮区域 -->
          <div class="create-post-section">
            <HSRButton size="large" :tag="null" :custom-icon-svg="uploadIconSvg" :icon-size="20"
              @click="handleCreatePostClick" class="create-post-btn">
              发布新帖
            </HSRButton>
          </div>

          <!-- 示例列表卡片 -->
          <div class="list-item-card" v-for="article in testArticles" :key="article.id" @click="openModal(article)">
            <div class="card-content">
              <div class="card-text-content"
                :class="{ 'full-width': !article.imageURL || article.imageURL.trim() === '' }">
                <div class="card-title">{{ sanitizeContent(article.title) }}</div>
                <div class="card-summary">
                  <span v-for="(part, index) in processContentHighlight(getFirstLine(article.summary))" :key="index">
                    <span v-if="part.type === 'highlight'" :style="{ color: part.color }">#{{ part.content }}#</span>
                    <span v-else>{{ part.content }}</span>
                  </span>
                </div>
                <div class="card-footer">
                  <div class="user-info">
                    <img v-if="article.avatar_url" :src="article.avatar_url" class="avatar" alt="用户头像" />
                    <div v-else class="avatar"></div>
                    <div class="username">
                      <span class="username-text">{{ processUsername(article.username).usernamePart }}</span>
                      <span class="username-tag" v-for="(tag, index) in processUsername(article.username).tags"
                        :key="index">
                        {{ tag }}
                      </span>
                    </div>
                  </div>
                  <div class="interaction-data">
                    <div class="like-container" @click.stop="toggleLike(article)" @mouseenter="article.hovered = true"
                      @mouseleave="article.hovered = false">
                      <div class="like-icon-wrapper">
                        <img :src="getLikeIconEmpty(article)" class="like-icon empty"
                          :class="{ 'hovered': article.hovered }" />
                        <img :src="getLikeIconFilled(article)" class="like-icon filled"
                          :class="{ 'active': article.liked, 'hovered': article.hovered }" />
                      </div>
                      <span class="like-count-text">{{ article.likes }}</span>
                    </div>
                    <div class="comment-container">
                      <img src="@/assets/discuss.png" class="comment-icon" />
                      <span class="comment-count-text">{{ article.comments }}</span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-image-container" v-if="article.imageURL && article.imageURL.trim() !== ''">
                <img :src="article.imageURL" class="card-image" />
                <div class="image-gradient-overlay"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- 竖屏提示（可选，即使显示平板也保留提示） -->
  <div v-if="!isLandscape && isMobile && !showPreloader" class="portrait-blocker">
    <div class="portrait-message">
      <p>横屏使用以获得最佳体验</p>
    </div>
  </div>

  <!-- 模态框 -->

  <div v-if="showModal" class="modal-overlay show">

    <div class="modal-container">

      <div class="modal-header" :class="{ 'no-image-header': !modalData.imageURL || modalData.imageURL.trim() === '' }">
        <button class="modal-close" @click="closeModal">
          <img src="@/assets/close.png" class="close-icon" alt="关闭" />
        </button>
      </div>

      <!-- 模态框加载动画 -->
      <div class="modal-loading-overlay" v-if="modalLoading">
        <svg class="modal-loading-spinner loading-circle" viewBox="0 0 50 50">
          <circle class="loading-path" cx="25" cy="25" r="20" fill="none" stroke="currentColor" stroke-width="5"></circle>
        </svg>
        <div class="modal-loading-text">加载中...</div>
      </div>

      <div class="modal-content" v-show="!modalLoading">
        <div class="modal-left" :class="{ 'no-image': !modalData.imageURL || modalData.imageURL.trim() === '' }">
          <svg class="modal-title" viewBox="0 0 600 100">
            <!-- 最外层灰 -->
            <text class="layer-gray" x="50%" y="50%" dominant-baseline="middle" text-anchor="middle">
              {{ sanitizeContent(modalData.title) }}
            </text>

            <!-- 中间白 -->
            <text class="layer-white" x="50%" y="50%" dominant-baseline="middle" text-anchor="middle">
              {{ sanitizeContent(modalData.title) }}
            </text>

            <!-- 最上层黑字 -->
            <text class="layer-black" x="50%" y="50%" dominant-baseline="middle" text-anchor="middle">
              {{ sanitizeContent(modalData.title) }}
            </text>
          </svg>

          <div class="modal-user-info">
            <img v-if="modalData.avatar_url" :src="modalData.avatar_url" class="user-avatar" alt="用户头像" />
            <div v-else class="user-avatar"></div>

            <div class="username">

              <span class="username-text" style="font-size: 16px;">{{ processUsername(modalData.username).usernamePart
              }}</span>

              <span class="username-tag" style="font-size: 14px;"
                v-for="(tag, index) in processUsername(modalData.username).tags" :key="index">

                {{ tag }}

              </span>

            </div>

            <div class="ip-location">

              <img src="@/assets/location.png" class="location-icon" alt="位置" />

              <span class="location-text">{{ modalData.location || '珠星大厦' }}</span>

            </div>
          </div>
          <div class="modal-left-content">
            <div class="modal-image-container" v-if="modalData.imageURL && modalData.imageURL.trim() !== ''">
              <el-image :src="modalData.imageURL" fit="contain" class="modal-image" show-progress
                @click="openImageViewer(modalData.imageURL)" style="cursor: zoom-in;">
                <template #error>
                  <div class="image-slot">
                    <el-icon :size="48">
                      <IconPicture />
                    </el-icon>
                    <span class="image-error-text">图片加载失败</span>
                  </div>
                </template>
              </el-image>
            </div>
          </div>

        </div>
        <div class="modal-right" :class="{ 'no-image': !modalData.imageURL || modalData.imageURL.trim() === '' }">

          <div class="modal-right-content">
            <div class="divider" style="margin-top: -14px !important;height: 1px !important;"></div>
            <div class="modal-article-content">

              <div class="modal-article-text">
                <div v-html="sanitizeHtmlContent(modalData.summary || '')" class="article-html-content"></div>
              </div>

            </div>

            <div class="modal-interactions">

              <div class="like-container" @click="toggleLike(modalData)" @mouseenter="modalData.hovered = true"
                @mouseleave="modalData.hovered = false">

                <div class="like-icon-wrapper">

                  <img :src="getLikeIconEmpty(modalData)" class="like-icon empty"
                    :class="{ 'hovered': modalData.hovered }" />

                  <img :src="getLikeIconFilled(modalData)" class="like-icon filled"
                    :class="{ 'active': modalData.liked, 'hovered': modalData.hovered }" />

                </div>

                <span class="like-count-text">{{ modalData.likes }}</span>

              </div>

              <div class="comment-container">

                <img src="@/assets/discuss.png" class="comment-icon" />

                <span class="comment-count-text">{{ modalData.comments }}</span>

              </div>

            </div>

            <div class="divider"></div>
            <div class="modal-comments">

              <!-- 文章评论输入框 -->
              <div class="article-comment-input">
                <HSRInput v-model="articleCommentText" type="textarea" placeholder="发表评论..." :rows="1"></HSRInput>
                <HSRButton size="small" :tag="null" :custom-icon-svg="confirmIconSvg" :icon-size="18"
                  @click="submitArticleComment" class="comment-submit-btn" :loading="isSubmittingComment">
                  发表评论
                </HSRButton>
              </div>

              <div class="comment-item" v-for="(comment, index) in modalData.commentsList" :key="comment.id || index"
                @click="startReply(comment)">

                <img v-if="comment.avatar_url" :src="comment.avatar_url" class="comment-avatar" alt="用户头像" />
                <div v-else class="comment-avatar"></div>

                <div class="comment-content">
                  <div class="comment-header">
                    <div class="comment-username" style="font-size: 15px !important;">{{ formatSafeUsername(comment.username) }}</div>
                    <div class="comment-actions">
                      <!-- 回复按钮 -->
                      <div class="reply-icon-btn" @click.stop="startReply(comment)" title="回复">
                        <span v-html="replyIconSvg" class="reply-icon"></span>
                      </div>
                      <!-- 删除按钮 -->
                      <div v-if="currentUser && comment.username === currentUser.username" class="delete-icon-btn"
                        @click.stop="deleteComment(comment)" title="删除评论">
                        <span v-html="deleteIconSvg" class="delete-icon"></span>
                      </div>
                    </div>
                  </div>

                  <div class="comment-text" v-html="formatSafeContent(comment.content)"></div>

                  <!-- 回复列表 -->
                  <div class="comment-replies" v-if="comment.replies && comment.replies.length > 0">
                    <div class="reply-item" v-for="(reply, replyIndex) in comment.replies" :key="replyIndex"
                      :id="`reply-${reply.id || reply.reply_id}`"
                      @click.stop="startReply(comment, reply)">
                      <img v-if="reply.avatar_url" :src="reply.avatar_url" class="reply-avatar" alt="用户头像" />
                      <div v-else class="reply-avatar"></div>
                      <div class="reply-content">
                        <div class="reply-header">
                          <div class="reply-username">{{ formatSafeUsername(reply.username) }}</div>
                          <div class="reply-actions">
                            <div class="reply-icon-btn" @click.stop="startReply(comment, reply)" title="回复">
                              <span v-html="replyIconSvg" class="reply-icon"></span>
                            </div>
                            <div v-if="currentUser && reply.username === currentUser.username" class="delete-icon-btn"
                              @click.stop="deleteReply(comment, reply)" title="删除回复">
                              <span v-html="deleteIconSvg" class="delete-icon"></span>
                            </div>
                          </div>
                        </div>
                        <div class="reply-text">
                          <span v-if="reply.reply_to">
                            回复 <span class="reply-mention clickable" @click.stop="scrollToReply(reply.reply_to, comment)">@{{ formatSafeUsername(reply.reply_to_user?.username || '用户') }}</span>: <span
                              v-html="formatSafeContent(reply.content)"></span>
                          </span>
                          <span v-else>
                            回复<span class="reply-mention">@{{ formatSafeUsername(comment.username) }}</span>: <span
                              v-html="formatSafeContent(reply.content)"></span>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                </div>

              </div>

            </div>

          </div>

        </div>

      </div>

      <div class="modal-bottom-decoration">

      </div>

    </div>

  </div>

  <!-- 登录注册模态框 -->
  <AuthModal :show="showAuthModal" @close="showAuthModal = false" @success="handleAuthSuccess" />
  <PostModal :show="showCreatePostModal" @close="showCreatePostModal = false" @submit="handlePostSubmit" />

  <!-- 头像选择模态框 -->
  <AvatarModal 
    :show="showAvatarModal" 
    :currentUser="currentUser"
    :presetAvatars="presetAvatars"
    @close="showAvatarModal = false"
    @updateAvatar="handleAvatarUpdate"
    @uploadAvatar="handleCustomAvatarUpload"
  />

  <!-- 确认模态框 -->
  <ConfirmModal 
    :show="showConfirmModal"
    :title="confirmModalTitle"
    :message="confirmModalMessage"
    :loading="confirmModalLoading"
    @confirm="handleConfirm"
    @cancel="handleCancel"
    @close="handleCancel"
  />

  <!-- 独立的全屏图片查看器 -->
  <el-image-viewer v-if="showImageViewer" :url-list="viewerImageList" :initial-index="viewerInitialIndex"
    @close="closeImageViewer" show-progress z-index="9999">
    <template #error>
      <div class="image-viewer-error-slot">
        <el-icon :size="64">
          <IconPicture />
        </el-icon>
        <span>图片加载失败</span>
      </div>
    </template>
  </el-image-viewer>

  <!-- 回复评论模态框 -->
  <div v-if="showReplyModal" class="reply-modal-overlay" :class="{ 'is-closing': isReplyModalClosing }"
    @click.self="cancelReply">
    <div class="reply-modal-container" :class="{ 'is-closing': isReplyModalClosing }">
      <div class="reply-modal-header">
        <h3 class="reply-modal-title">
          {{ replyingToReply ? `回复 @${replyingToReply.username}` : `回复 ${replyingToComment?.username}` }}
        </h3>
        <div class="reply-modal-close" @click="cancelReply">
          <img src="@/assets/close.png" class="reply-close-icon" alt="关闭" />
        </div>
      </div>
      <div class="reply-modal-body">
        <div class="reply-original-content">
          <span class="reply-original-label">{{ replyingToReply ? '原回复：' : '原评论：' }}</span>
          <span class="reply-original-text">{{ replyingToReply ? replyingToReply.content : replyingToComment?.content }}</span>
        </div>
        <HSRInput v-model="replyTextMap[replyingToComment?.id]" type="textarea"
          :placeholder="replyingToReply ? `回复 @${replyingToReply.username}...` : `回复 ${replyingToComment?.username}...`" :rows="5"></HSRInput>
      </div>
      <div class="reply-modal-footer">
        <HSRButton size="small" :tag="null" :custom-icon-svg="cancelIconSvg" :icon-size="16" @click="cancelReply"
          :disabled="isSubmittingReply">取消</HSRButton>
        <HSRButton size="small" :tag="null" :custom-icon-svg="confirmIconSvg" :icon-size="16"
          @click="submitReply(replyingToComment)"
          :loading="isSubmittingReply || !replyTextMap[replyingToComment?.id]?.trim()">
          确认
        </HSRButton>
      </div>
    </div>
  </div>

</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue';
import { Check, Picture as IconPicture } from '@element-plus/icons-vue';
import { ElMessage } from 'element-plus';
import { articleAPI, userAPI } from './services/api';
import { sanitizeContent, sanitizeUsername, sanitizeHtmlContent } from './utils/security';
import AuthModal from './components/AuthModal.vue';
import PostModal from './components/PostModal.vue';
import AvatarModal from './components/AvatarModal.vue';
import ConfirmModal from './components/ConfirmModal.vue';
import HSRInput from './components/HSRInput.vue';

// 注册组件
defineOptions({
  components: {
    HSRInput
  }
});

// 星穹铁道风格 - 回复/评论图标
const replyIconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M800 128H224C171 128 128 171 128 224v680l160-128h512c53 0 96-43 96-96V224c0-53-43-96-96-96zm32 544c0 17.6-14.4 32-32 32H273.5L192 768V224c0-17.6 14.4-32 32-32h576c17.6 0 32 14.4 32 32v448z"/>
  
  <rect x="300" y="440" width="80" height="80" fill="currentColor" transform="rotate(45 340 480)" />
  <rect x="472" y="440" width="80" height="80" fill="currentColor" transform="rotate(45 512 480)" />
  <rect x="644" y="440" width="80" height="80" fill="currentColor" transform="rotate(45 684 480)" />
</svg>`;

// 星穹铁道风格 - 确认图标

const confirmIconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024"><path fill="currentColor" d="M77.248 415.04a64 64 0 0 1 90.496 0l226.304 226.304L846.528 188.8a64 64 0 1 1 90.56 90.496l-543.04 543.04-316.8-316.8a64 64 0 0 1 0-90.496"></path></svg>`;



// 星穹铁道风格 - 发送/传送图标

const sendIconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024"><path fill="currentColor" d="m64 448 832-320-128 704-446.08-243.328L832 192 242.816 545.472zm256 512V657.024L512 768z"></path></svg>`;

// 星穹铁道风格 - 取消/关闭图标
const cancelIconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024"><path fill="currentColor" d="M195.2 195.2a64 64 0 0 1 90.496 0L512 421.504 738.304 195.2a64 64 0 0 1 90.496 90.496L602.496 512 828.8 738.304a64 64 0 0 1-90.496 90.496L512 602.496 285.696 828.8a64 64 0 0 1-90.496-90.496L421.504 512 195.2 285.696a64 64 0 0 1 0-90.496"></path></svg>`;

// 星穹铁道风格 - 删除图标
const deleteIconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024"><path fill="currentColor" d="M352 192V95.936a32 32 0 0 1 32-32h256a32 32 0 0 1 32 32V192h256a32 32 0 0 1 0 64H96a32 32 0 0 1 0-64zm64 0h192v-64H416zM192 960a32 32 0 0 1-32-32V256h704v672a32 32 0 0 1-32 32zm224-192a32 32 0 0 0 32-32V416a32 32 0 0 0-64 0v320a32 32 0 0 0 32 32m192 0a32 32 0 0 0 32-32V416a32 32 0 0 0-64 0v320a32 32 0 0 0 32 32"></path></svg>`;

// 星穹铁道风格 - 上传图标
const uploadIconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024"><path fill="currentColor" d="M160 832h704a32 32 0 1 1 0 64H160a32 32 0 1 1 0-64m384-578.304V704h-64V247.296L237.248 490.048 192 444.8 508.8 128l316.8 316.8-45.312 45.248z"></path></svg>`;

// 星穹铁道风格 - 发表评论图标
const submitCommentIconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024"><path fill="currentColor" d="m64 448 832-320-128 704-446.08-243.328L832 192 242.816 545.472zm256 512V657.024L512 768z"></path></svg>`;

// 星穹铁道风格 - 用户图标
const userIconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024"><path fill="currentColor" d="M288 320a224 224 0 1 0 448 0 224 224 0 1 0-448 0m544 608H160a32 32 0 0 1-32-32v-96a160 160 0 0 1 160-160h448a160 160 0 0 1 160 160v96a32 32 0 0 1-32 32z"></path></svg>`;

// 测试文章数据 - 从API获取
const testArticles = ref([]);

// 获取文章列表
const fetchArticles = async () => {
  try {
    const articles = await articleAPI.getArticles();
    
    // 获取所有文章作者的头像
    const usernameSet = new Set(articles.map((a) => a.username));
    const avatarPromises = Array.from(usernameSet).map(async (username) => {
      const avatar = await getUserAvatar(username);
      return { username, avatar };
    });
    
    const avatarResults = await Promise.all(avatarPromises);
    const avatarMap = new Map(avatarResults.map(r => [r.username, r.avatar]));
    
    testArticles.value = articles.map((article) => ({
      id: article.article_id,
      title: article.title,
      summary: article.content,
      username: article.username,
      likes: article.like_count,
      comments: article.comment_count,
      imageURL: article.cover_url,
      avatar_url: avatarMap.get(article.username) || '',
      liked: article.is_liked || false,
      hovered: false,
      location: ''
    }));
  } catch (error) {
    console.error('获取文章列表失败:', error);
    // 如果API调用失败，使用测试数据
    testArticles.value = [
      {
        id: 1,
        title: "文章加载失败",
        summary: "文章加载失败",
        username: "文章加载失败",
        likes: 100,
        comments: 50,
        imageURL: "@/assets/bg.png",
        avatar_url: '',
        liked: false,
        hovered: false,
        location: "文章加载失败"
      }
    ];
  }
};

// 初始化时获取文章
fetchArticles();

// 高亮颜色
const highlightColor = ref('#d08054');

// 预加载相关变量
const showPreloader = ref(true);
const loadingProgress = ref(0);

const isShrunk = ref(false);
const showCenterLogo = ref(false); // 在预加载完成后才开始动画
const showSidebarContent = ref(false);
const showRightContent = ref(false); // 控制右侧内容显示
const tabletRef = ref(null);
const isLandscape = ref(window.innerWidth > window.innerHeight);
const isMobile = ref(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent));

// 核心逻辑：使用设计稿缩放逻辑，始终在1920x1080画布上开发
const handleZoomCompensation = () => {
  if (!tabletRef.value) return;

  // 设定标准平板开发尺寸 (16:9)
  const DESIGN_W = 1920;
  const DESIGN_H = 1080;

  const winW = window.innerWidth;
  const winH = window.innerHeight;

  // 计算适配比例 - 确保平板始终保持16:9比例
  const scaleX = winW / DESIGN_W;
  const scaleY = winH / DESIGN_H;
  const scale = Math.min(scaleX, scaleY); // 取较小值，确保平板完全显示在屏幕内

  // 强制设置容器为标准尺寸
  tabletRef.value.style.width = `${DESIGN_W}px`;
  tabletRef.value.style.height = `${DESIGN_H}px`;

  // 通过 transform 缩放实现全设备适配
  // 无论手机还是 PC，内部元素看到的都是 1920x1080
  tabletRef.value.style.transform = `scale(${scale})`;
  tabletRef.value.style.transformOrigin = 'center center';

  // 输出调试信息到控制台而不是弹窗
  console.log(`适配比例: ${scale}, 窗口: ${winW}x${winH}, 设计稿: ${DESIGN_W}x${DESIGN_H}`);
};

// 检测屏幕方向变化
const handleOrientationChange = () => {
  isLandscape.value = window.innerWidth > window.innerHeight;
  // 窗口大小改变时重新计算尺寸
  handleZoomCompensation();
};

onMounted(() => {
  // 首先执行预加载
  preloadAssets().then(() => {
    console.log('预加载完成，开始初始化平板界面');
    // 隐藏预加载页面
    showPreloader.value = false;

    // 显示中心logo开始动画流程
    showCenterLogo.value = true;

    // 监听缩放和窗口变化
    window.addEventListener('resize', handleZoomCompensation);
    window.addEventListener('resize', handleOrientationChange);

    // 立即执行缩放补偿，确保平板正确显示
    setTimeout(() => {
      handleZoomCompensation();
      console.log('缩放补偿函数已执行');
    }, 100); // 延迟一点执行，确保DOM更新完成

    // 开始正常渲染流程
    setTimeout(() => {
      startNormalFlow();
      console.log('正常渲染流程已启动');
    }, 200); // 稍微延后开始动画流程

  }).catch(error => {
    console.error('预加载出错:', error);
    // 即使预加载出错也继续正常流程
    showPreloader.value = false;
    showCenterLogo.value = true;

    // 监听缩放和窗口变化
    window.addEventListener('resize', handleZoomCompensation);
    window.addEventListener('resize', handleOrientationChange);

    // 立即执行缩放补偿
    setTimeout(() => {
      handleZoomCompensation();
      console.log('缩放补偿函数已执行（错误路径）');
    }, 100);

    // 开始正常渲染流程
    setTimeout(() => {
      startNormalFlow();
      console.log('正常渲染流程已启动（错误路径）');
    }, 200);
  });

  // 添加一个备用方案，防止预加载卡住
  setTimeout(() => {
    if (showPreloader.value) {
      console.log('备用方案：强制隐藏预加载页面');
      showPreloader.value = false;
      showCenterLogo.value = true;

      // 监听缩放和窗口变化
      window.addEventListener('resize', handleZoomCompensation);
      window.addEventListener('resize', handleOrientationChange);

      // 立即执行缩放补偿
      setTimeout(() => {
        handleZoomCompensation();
        console.log('缩放补偿函数已执行（备用方案）');
      }, 100);

      // 开始正常渲染流程
      setTimeout(() => {
        startNormalFlow();
        console.log('正常渲染流程已启动（备用方案）');
      }, 200);
    }
  }, 3000); // 3秒后强制继续
});

onUnmounted(() => {
  window.removeEventListener('resize', handleZoomCompensation);
  window.removeEventListener('resize', handleOrientationChange);
});

const onAnimationEnd = () => {
  showCenterLogo.value = false;
};

// 控制bg_w区域的移动和内容显示
const animateBgWRegion = () => {
  // bg_w动画的总时长
  const duration = 1500; // 毫秒
  const startTime = Date.now();

  const animate = () => {
    const elapsed = Date.now() - startTime;
    const progress = Math.min(elapsed / duration, 1);

    // 更新右侧内容区域的显示状态
    if (progress >= 0.8 && !showRightContent.value) {
      showRightContent.value = true;
    }

    if (progress < 1) {
      requestAnimationFrame(animate);
    }
  };

  requestAnimationFrame(animate);
};

// 预加载资源
const preloadAssets = () => {
  return new Promise((resolve) => {
    // 预加载所有图片资源
    const imagePaths = [
      new URL('@/assets/logo.png', import.meta.url).href,
      new URL('@/assets/monkey.png', import.meta.url).href,
      new URL('@/assets/bg.png', import.meta.url).href,
      new URL('@/assets/bg_w.png', import.meta.url).href,
      new URL('@/assets/qipao.png', import.meta.url).href,
      new URL('@/assets/back.png', import.meta.url).href,
      new URL('@/assets/cursor.png', import.meta.url).href,
      new URL('@/assets/exm.jpeg', import.meta.url).href
    ];

    let loadedCount = 0;
    const totalCount = imagePaths.length;

    // 更新进度条
    const updateProgress = () => {
      loadedCount++;
      loadingProgress.value = Math.round((loadedCount / totalCount) * 100);
      if (loadedCount >= totalCount) {
        setTimeout(() => {
          console.log('所有资源加载完成');
          resolve();
        }, 300); // 稍微延迟一下，让用户看到加载完成
      }
    };

    // 如果没有需要预加载的图片，直接完成
    if (totalCount === 0) {
      updateProgress();
      return;
    }

    console.log('开始预加载', totalCount, '个资源');

    // 创建图片对象进行预加载
    imagePaths.forEach(src => {
      const img = new Image();
      img.onload = () => {
        console.log('资源加载成功:', src);
        updateProgress();
      };
      img.onerror = () => {
        console.log('资源加载失败:', src);
        updateProgress(); // 即使加载失败也计入进度，避免卡住
      };
      img.src = src;
    });

  });
};

// 预加载文章列表中的图片
const preloadArticleImages = async (articles) => {
  const imageUrls = new Set();

  // 收集所有图片URL
  articles.forEach(article => {
    if (article.cover_url) {
      imageUrls.add(article.cover_url);
    }
    if (article.avatar_url) {
      imageUrls.add(article.avatar_url);
    }
  });

  console.log('需要预加载的文章图片数量:', imageUrls.size);

  // 预加载所有图片
  const promises = Array.from(imageUrls).map(url => {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        console.log('文章图片加载成功:', url);
        resolve(true);
      };
      img.onerror = () => {
        console.log('文章图片加载失败:', url);
        resolve(false);
      };
      img.src = url;
    });
  });

  await Promise.all(promises);
};

// 处理右侧内容区域的滚动
const updateScrollIndicator = (event) => {
  const container = event.target;
  const scrollPercentage = container.scrollTop / (container.scrollHeight - container.clientHeight);

  // 更新滚动条指示器位置
  const indicator = document.querySelector('.scroll-indicator');
  if (indicator) {
    const maxIndicatorPosition = container.clientHeight - 100; // 100 is indicator height
    const indicatorPosition = Math.min(scrollPercentage * maxIndicatorPosition, maxIndicatorPosition);
    indicator.style.top = `${indicatorPosition}px`;
  }
};

// 开始正常渲染流程
const startNormalFlow = () => {
  // 动画流程

  setTimeout(() => {
    isShrunk.value = true;
    setTimeout(() => {
      showSidebarContent.value = true;
    }, 660);

    // 启动bg_w区域动画
    setTimeout(() => {
      animateBgWRegion();
    }, 0); // 在sidebar开始收缩后启动bg_w动画
  }, 300);
};

// 处理文章内容中的#xxx#高亮显示
const processContentHighlight = (text) => {
  if (!text) return '';
  // 使用正则表达式匹配 #xxx# 模式
  const regex = /(#.*?#)/g;
  const parts = text.split(regex);

  return parts.map((part, index) => {
    if (part.startsWith('#') && part.endsWith('#')) {
      // 这是高亮部分
      return {
        type: 'highlight',
        content: sanitizeContent(part.slice(1, -1)), // 去掉首尾的#并过滤
        color: highlightColor.value
      };
    } else {
      // 普通文本
      return {
        type: 'text',
        content: sanitizeContent(part) // 过滤普通文本
      };
    }
  });
};

// 安全过滤：显示评论内容
const formatSafeContent = (text) => {
  if (!text) return '';
  return formatContent(sanitizeContent(text));
};

// 安全过滤：显示用户名
const formatSafeUsername = (username) => {
  if (!username) return '';
  return sanitizeUsername(username);
};

// 格式化文章内容（保留富文本格式）
const formatArticleContent = (content) => {
  if (!content) return '';
  // 直接返回内容，让 v-html 渲染 HTML
  return content;
};

// 格式化内容，将 \n 转换为 <br>，最多 10 个
const formatContent = (text) => {
  if (!text) return '';

  // 分割文本为行
  const lines = text.split('\n');

  // 只保留前 10 行
  const maxLines = 10;
  if (lines.length <= maxLines) {
    // 如果不超过 10 行，直接替换换行符
    return text.replace(/\n/g, '<br>');
  }

  // 超过 10 行，前 10 行保留换行，后面的行合并为空格
  const first10Lines = lines.slice(0, maxLines).join('<br>');
  const remainingLines = lines.slice(maxLines).join(' ');

  return first10Lines + '<br>' + remainingLines;
};

// 获取文章内容的第一行
const getFirstLine = (text) => {
  if (!text) return '';
  // 分割文本并只取第一行
  const lines = text.split('\n');
  return lines[0] || '';
};

// 处理用户名中的[xxx]灰色方框
const processUsername = (username) => {
  if (!username) return { usernamePart: '', tags: [] };

  // 查找 [xxx] 模式
  const regex = /\[([^\]]+)\]/g;
  const matches = [...username.matchAll(regex)];

  // 提取标签
  const tags = matches.map(match => match[1]);

  // 分离用户名和标签部分，移除[xxx]部分，保留前面的文本
  const usernamePart = sanitizeUsername(username.replace(/\[[^\]]+\]/g, '').trim());

  return {
    usernamePart: usernamePart,
    tags: tags.map(tag => sanitizeContent(tag))
  };
};

// 点赞功能
const toggleLike = async (article) => {
  if (!currentUser.value) {
    // 未登录，显示登录模态框
    showAuthModal.value = true;
    return;
  }

  try {
    await articleAPI.likeArticle(article.id.toString());

    // 更新本地状态
    if (article.liked) {
      article.liked = false;
      article.likes = Math.max(0, article.likes - 1);
    } else {
      article.liked = true;
      article.likes += 1;
    }

    // 同步更新到文章列表
    syncArticleToList(article);
  } catch (error) {
    console.error('点赞失败:', error);
    ElMessage.error('点赞失败，请重试');
  }
};

// 获取空心点赞图标（底层）
const getLikeIconEmpty = (article) => {
  if (article.hovered) {
    // hover状态 - 显示like0_h.png
    return new URL('@/assets/like0_h.png', import.meta.url).href;
  } else {
    // 正常状态 - 显示like0.png
    return new URL('@/assets/like0.png', import.meta.url).href;
  }
};

// 获取实心点赞图标（上层）
const getLikeIconFilled = (article) => {
  if (article.hovered) {
    // hover状态 - 显示like1_h.png
    return new URL('@/assets/like1_h.png', import.meta.url).href;
  } else {
    // 正常状态 - 显示like1.png
    return new URL('@/assets/like1.png', import.meta.url).href;
  }
};

// 模态框相关数据
const showModal = ref(false);
const modalLoading = ref(false); // 模态框内容加载状态
const modalData = ref({
  title: '',
  summary: '',
  imageURL: '',
  tags: [],
  likes: 0,
  comments: 0,
  liked: false,
  hovered: false,
  commentsList: []
});

// 登录相关状态
const showAuthModal = ref(false);
const showAvatarModal = ref(false);
const showCreatePostModal = ref(false);
const showConfirmModal = ref(false);
const confirmModalTitle = ref('确认');
const confirmModalMessage = ref('是否确认此操作？');
const confirmModalLoading = ref(false);
const pendingDeleteAction = ref(null);
const currentUser = ref(null);

// 头像缓存
const avatarCache = ref(new Map());

// 预设头像列表
const presetAvatars = [
  new URL('@/assets/presets/huahuo.png', import.meta.url).href,
  new URL('@/assets/presets/huohua.png', import.meta.url).href,
  new URL('@/assets/presets/kafuka.png', import.meta.url).href,
  new URL('@/assets/presets/yaoguang.png', import.meta.url).href,
  new URL('@/assets/presets/yinlang.png', import.meta.url).href,
  new URL('@/assets/presets/busitu.png', import.meta.url).href,
  new URL('@/assets/presets/waerte.png', import.meta.url).href,
  new URL('@/assets/presets/sanyueqi.png', import.meta.url).href,
];

// 头像更新加载状态
const isUpdatingAvatar = ref(false);

// 自定义头像相关状态
const customAvatarPreview = ref('');
const customAvatarBase64 = ref('');
const uploading = ref(false);

// 图片查看器相关状态
const showImageViewer = ref(false);
const viewerImageList = ref([]);
const viewerInitialIndex = ref(0);

// 打开图片查看器
const openImageViewer = (imageUrl) => {
  viewerImageList.value = [imageUrl];
  viewerInitialIndex.value = 0;
  showImageViewer.value = true;
};

// 关闭图片查看器
const closeImageViewer = () => {
  showImageViewer.value = false;
};

// 触发文件上传
const triggerFileUpload = () => {
  console.log('triggerFileUpload called');

  // 创建临时的文件输入元素
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'image/*';
  input.style.display = 'none';

  // 监听文件选择事件
  input.addEventListener('change', (event) => {
    const target = event.target;
    const file = target.files?.[0];

    if (file) {
      handleFileUpload({ target });
    }

    // 清理临时元素
    document.body.removeChild(input);
  });

  // 添加到 DOM 并触发点击
  document.body.appendChild(input);
  input.click();
};

// 处理文件上传
const handleFileUpload = async (event) => {
  const target = event.target;
  const file = target.files?.[0];

  if (!file) return;

  // 验证文件类型
  if (!file.type.startsWith('image/')) {
    ElMessage.error('请选择图片文件');
    return;
  }

  // 验证文件大小（限制为5MB）
  if (file.size > 5 * 1024 * 1024) {
    ElMessage.error('图片大小不能超过5MB');
    return;
  }

  try {
    // 压缩图片并转换为base64
    const compressedBase64 = await compressImage(file, 800, 0.8);
    customAvatarBase64.value = compressedBase64;
    customAvatarPreview.value = compressedBase64;
  } catch (error) {
    console.error('图片处理失败:', error);
    ElMessage.error('图片处理失败，请重试');
  }

  // 清空input，允许重复选择同一文件
  target.value = '';
};

// 确认上传自定义头像
const confirmCustomAvatarUpload = async () => {
  if (!customAvatarBase64.value) return;

  uploading.value = true;
  try {
    await userAPI.updateAvatar(customAvatarBase64.value);

    // 更新本地用户信息
    if (currentUser.value) {
      currentUser.value.avatar_url = customAvatarBase64.value;
      localStorage.setItem('user', JSON.stringify(currentUser.value));
    }

    showAvatarModal.value = false;
    ElMessage.success('头像更新成功');

    // 清空预览
    customAvatarPreview.value = '';
    customAvatarBase64.value = '';
  } catch (error) {
    ElMessage.error('头像上传失败');
    console.error('上传头像失败:', error);
  } finally {
    uploading.value = false;
  }
};

// 取消自定义头像
const cancelCustomAvatar = () => {
  customAvatarPreview.value = '';
  customAvatarBase64.value = '';
};

// 检查登录状态
const checkLoginStatus = async () => {
  const userStr = localStorage.getItem('user');
  if (userStr) {
    currentUser.value = JSON.parse(userStr);
    // 获取用户头像
    if (currentUser.value?.username) {
      try {
        const avatar = await getUserAvatar(currentUser.value.username);
        if (avatar) {
          currentUser.value.avatar_url = avatar;
        }
      } catch (error) {
        console.error('获取用户头像失败:', error);
      }
    }
  }
};

// 处理登录成功
const handleAuthSuccess = async (user) => {
  currentUser.value = user;
  // 获取用户头像
  if (user.username) {
    try {
      const avatar = await getUserAvatar(user.username);
      if (avatar) {
        currentUser.value.avatar_url = avatar;
      }
    } catch (error) {
      console.error('获取用户头像失败:', error);
    }
  }
};

// 处理用户名点击
const handleUsernameClick = () => {
  if (currentUser.value) {
    // 已登录，点击用户名不做任何事（或者可以显示用户信息）
    return;
  } else {
    // 未登录，显示登录模态框
    showAuthModal.value = true;
  }
};

// 退出登录
const handleLogout = () => {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  currentUser.value = null;
  ElMessage.success('已退出登录');
};

// 打开头像设置
const openAvatarSettings = () => {
  showAvatarModal.value = true;
};

// 处理发帖按钮点击
const handleCreatePostClick = () => {
  if (!currentUser.value) {
    // 未登录，显示登录模态框
    showAuthModal.value = true;
    return;
  }
  // 已登录，打开发帖模态框
  showCreatePostModal.value = true;
};

// 处理发帖提交
const handlePostSubmit = async (postData) => {
  if (!currentUser.value) {
    ElMessage.error('请先登录');
    return;
  }

  try {
    // 准备图片数据
    let imageBase64 = '';
    if (postData.images && postData.images.length > 0) {
      imageBase64 = postData.images[0]; // 使用第一张图片
    }

    // 调用 API 创建文章
    const result = await articleAPI.createArticle(
      postData.title,
      postData.content,
      imageBase64 || undefined,
      'default'
    );

    ElMessage.success('发帖成功');

    // 重新获取文章列表
    await fetchArticles();

    // 关闭模态框
    showCreatePostModal.value = false;
  } catch (error) {
    console.error('发帖失败:', error);
    ElMessage.error('发帖失败，请重试');
  }
};

// 处理 AvatarModal 的头像更新事件
const handleAvatarUpdate = async (avatarUrl) => {
  if (isUpdatingAvatar.value) return;

  try {
    isUpdatingAvatar.value = true;

    // 将图片 URL 转换为 base64（JPEG 格式）
    const base64Data = await convertImageToBase64(avatarUrl);

    await userAPI.updateAvatar(base64Data);

    // 更新本地用户信息
    if (currentUser.value) {
      currentUser.value.avatar_url = base64Data;
      localStorage.setItem('user', JSON.stringify(currentUser.value));
    }
    showAvatarModal.value = false;
    ElMessage.success('头像更新成功');
  } catch (error) {
    ElMessage.error('头像更新失败');
    console.error('更新头像失败:', error);
  } finally {
    isUpdatingAvatar.value = false;
  }
};

// 处理 AvatarModal 的自定义头像上传事件
const handleCustomAvatarUpload = async (base64Data) => {
  if (!base64Data) return;

  uploading.value = true;
  try {
    await userAPI.updateAvatar(base64Data);

    // 更新本地用户信息
    if (currentUser.value) {
      currentUser.value.avatar_url = base64Data;
      localStorage.setItem('user', JSON.stringify(currentUser.value));
    }
    showAvatarModal.value = false;
    ElMessage.success('头像上传成功');
  } catch (error) {
    ElMessage.error('头像上传失败');
    console.error('上传头像失败:', error);
  } finally {
    uploading.value = false;
  }
};

// 更新头像
const updateAvatar = async (avatarUrl) => {
  if (isUpdatingAvatar.value) return;

  try {
    isUpdatingAvatar.value = true;

    // 将图片 URL 转换为 base64（JPEG 格式）
    const base64Data = await convertImageToBase64(avatarUrl);

    await userAPI.updateAvatar(base64Data);

    // 更新本地用户信息
    if (currentUser.value) {
      currentUser.value.avatar_url = base64Data;
      localStorage.setItem('user', JSON.stringify(currentUser.value));
    }
    showAvatarModal.value = false;
    ElMessage.success('头像更新成功');
  } catch (error) {
    ElMessage.error('头像更新失败');
    console.error('更新头像失败:', error);
  } finally {
    isUpdatingAvatar.value = false;
  }
};

// 回复相关状态
const replyingTo = ref(null); // 当前正在回复的评论ID
const replyTextMap = ref({}); // 回复文本映射，key为评论ID
const showReplyModal = ref(false); // 回复模态框显示状态
const replyingToComment = ref(null); // 当前正在回复的评论对象
const replyingToReply = ref(null); // 当前正在回复的回复对象（如果有）
const isReplyModalClosing = ref(false); // 回复模态框关闭动画状态
const isSubmittingReply = ref(false); // 提交回复的加载状态
const articleCommentText = ref(''); // 文章评论文本
const isSubmittingComment = ref(false); // 提交评论加载状态

// 图片压缩工具函数（温和压缩）
const compressImage = (file, maxWidth = 800, quality = 0.8) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        // 计算压缩后的尺寸
        if (width > maxWidth) {
          height = (height * maxWidth) / width;
          width = maxWidth;
        }

        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
          resolve(compressedDataUrl);
        } else {
          reject(new Error('无法获取canvas上下文'));
        }
      };
      img.onerror = () => reject(new Error('图片加载失败'));
    };
    reader.onerror = () => reject(new Error('文件读取失败'));
  });
};

// 图片 URL 转 base64 函数
const convertImageToBase64 = (imageUrl) => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';

    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;

      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0);

      try {
        // 强制使用 JPEG 格式，避免 RGBA 问题
        const base64 = canvas.toDataURL('image/jpeg', 0.9);
        resolve(base64);
      } catch (error) {
        // 如果 canvas 被污染，使用 fetch 方式
        fetch(imageUrl)
          .then(response => response.blob())
          .then(blob => {
            return new Promise((resolve2, reject2) => {
              const reader = new FileReader();
              reader.onloadend = () => {
                // 将 PNG 转换为 JPEG
                const tempImg = new Image();
                tempImg.onload = () => {
                  const tempCanvas = document.createElement('canvas');
                  tempCanvas.width = tempImg.width;
                  tempCanvas.height = tempImg.height;
                  const tempCtx = tempCanvas.getContext('2d');
                  tempCtx.drawImage(tempImg, 0, 0);
                  const jpegBase64 = tempCanvas.toDataURL('image/jpeg', 0.9);
                  resolve2(jpegBase64);
                };
                tempImg.onerror = () => resolve2(reader.result);
                tempImg.src = reader.result;
              };
              reader.onerror = reject2;
              reader.readAsDataURL(blob);
            });
          })
          .then(resolve)
          .catch(reject);
      }
    };

    img.onerror = () => {
      // 如果 canvas 方式失败，使用 fetch 方式
      fetch(imageUrl)
        .then(response => response.blob())
        .then(blob => {
          return new Promise((resolve2, reject2) => {
            const reader = new FileReader();
            reader.onloadend = () => {
              // 将 PNG 转换为 JPEG
              const tempImg = new Image();
              tempImg.onload = () => {
                const tempCanvas = document.createElement('canvas');
                tempCanvas.width = tempImg.width;
                tempCanvas.height = tempImg.height;
                const tempCtx = tempCanvas.getContext('2d');
                tempCtx.drawImage(tempImg, 0, 0);
                const jpegBase64 = tempCanvas.toDataURL('image/jpeg', 0.9);
                resolve2(jpegBase64);
              };
              tempImg.onerror = () => resolve2(reader.result);
              tempImg.src = reader.result;
            };
            reader.onerror = reject2;
            reader.readAsDataURL(blob);
          });
        })
        .then(resolve)
        .catch(reject);
    };

    img.src = imageUrl;
  });
};

// 获取用户头像
const getUserAvatar = async (username) => {
  // 如果缓存中有，直接返回
  if (avatarCache.value.has(username)) {
    return avatarCache.value.get(username);
  }

  try {
    const result = await userAPI.getAvatar(username);
    if (!result || !result.avatar_url) {
      console.warn(`用户 ${username} 头像数据为空`);
      return '';
    }
    const avatarUrl = result.avatar_url;
    avatarCache.value.set(username, avatarUrl);
    return avatarUrl;
  } catch (error) {
    console.error(`获取用户 ${username} 头像失败:`, error);
    // 返回默认头像
    return '';
  }
};

// 打开模态框
const openModal = async (article) => {
  showModal.value = true;
  modalLoading.value = true; // 开始加载

  // 锁定body滚动
  document.body.style.overflow = 'hidden';

  try {
    // 同时获取文章详情和评论
    const [detail, comments] = await Promise.all([
      articleAPI.getArticleDetail(article.id.toString()),
      articleAPI.getArticleComments(article.id.toString())
    ]);

    // 收集所有需要获取头像的用户名（文章作者 + 所有评论者 + 所有回复者）
    const usernameSet = new Set();
    usernameSet.add(detail.username);
    comments.forEach(comment => {
      usernameSet.add(comment.username);
      comment.replies?.forEach((reply) => {
        usernameSet.add(reply.username);
      });
    });

    // 获取所有用户头像
    const avatarPromises = Array.from(usernameSet).map(async (username) => {
      const avatar = await getUserAvatar(username);
      return { username, avatar };
    });
    
    const avatarResults = await Promise.all(avatarPromises);
    const avatarMap = new Map(avatarResults.map(r => [r.username, r.avatar]));

    // 复制文章数据到模态框数据
    modalData.value = {
      ...article,
      ...detail,
      location: detail.location || article.location || '北京',
      avatar_url: avatarMap.get(detail.username) || article.avatar_url,
      commentsList: comments.map((comment, index) => {
        // 尝试多个可能的 ID 字段
        const commentId = comment.id || comment.comment_id || comment._id || `comment-${index}`;
        return {
          id: commentId,
          realId: comment.comment_id || comment.id, // 保存真实 ID 用于 API 调用
          username: comment.username,
          avatar_url: avatarMap.get(comment.username) || '',
          content: comment.content,
          replies: (comment.replies || []).map((reply, replyIndex) => ({
            id: reply.id || reply.reply_id || `reply-${index}-${replyIndex}`,
            username: reply.username,
            avatar_url: avatarMap.get(reply.username) || '',
            content: reply.content,
            reply_to: reply.reply_to,
            reply_to_user: reply.reply_to_user
          }))
        };
      })
    };
  } catch (error) {
    console.error('获取文章详情或评论失败:', error);
    // 如果API调用失败，使用文章数据和测试评论
    modalData.value = {
      ...article,
      location: article.location || '北京',
      avatar_url: article.avatar_url,
      commentsList: [
      ]
    };
  } finally {
    modalLoading.value = false; // 加载完成
  }
};

// 关闭模态框
const closeModal = () => {
  // 添加关闭动画类
  const modalContainer = document.querySelector('.modal-container');
  const modalOverlay = document.querySelector('.modal-overlay');

  if (modalContainer) {
    modalContainer.classList.add('closing');
  }

  if (modalOverlay) {
    modalOverlay.classList.add('hiding');
  }

  // 延迟关闭以完成动画
  setTimeout(() => {
    showModal.value = false;

    // 解锁body滚动
    document.body.style.overflow = '';

    // 移除关闭动画类，以便下次打开时可以重新应用动画
    if (modalContainer) {
      modalContainer.classList.remove('closing');
    }

    if (modalOverlay) {
      modalOverlay.classList.remove('hiding');
    }
  }, 250); /* 更新延迟时间以匹配新的动画速度 */
};

// 处理ESC键关闭模态框
const handleEscKey = (event) => {
  if (event.key === 'Escape' && showModal.value) {
    closeModal();
  }
};

// 监听键盘事件
onMounted(() => {
  window.addEventListener('keydown', handleEscKey);
  checkLoginStatus();
});

// 移除键盘事件监听器
onUnmounted(() => {
  window.removeEventListener('keydown', handleEscKey);
});


// 开始回复评论
const startReply = (comment, reply = null) => {
  console.log('startReply called with comment:', comment, 'reply:', reply);
  const commentId = String(comment.id);
  console.log('comment.id:', commentId);

  replyingTo.value = commentId;
  replyingToComment.value = comment;
  replyingToReply.value = reply;
  showReplyModal.value = true;

  // 初始化该评论的回复文本
  if (!replyTextMap.value[commentId]) {
    replyTextMap.value[commentId] = '';
  }
};

// 取消回复
const cancelReply = () => {
  if (!showReplyModal.value) return;

  // 先触发关闭动画
  isReplyModalClosing.value = true;

  // 等待动画完成后再关闭模态框
  setTimeout(() => {
    replyingTo.value = null;
    replyingToComment.value = null;
    replyingToReply.value = null;
    showReplyModal.value = false;
    if (replyingToComment.value) {
      replyTextMap.value[replyingToComment.value.id] = '';
    }
    isReplyModalClosing.value = false;
  }, 200); // 与 CSS 动画时长一致
};

// 滚动到指定回复
const scrollToReply = (replyId, comment) => {
  const targetElement = document.getElementById(`reply-${replyId}`);
  if (targetElement) {
    targetElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
    // 高亮显示
    targetElement.classList.add('reply-highlight');
    setTimeout(() => {
      targetElement.classList.remove('reply-highlight');
    }, 2000);
  } else {
    ElMessage.warning('未找到该回复');
  }
};

// 同步文章数据到文章列表
const syncArticleToList = (article) => {
  const index = testArticles.value.findIndex(a => a.id === article.id);
  if (index !== -1) {
    // 更新文章列表中的数据
    testArticles.value[index] = {
      ...testArticles.value[index],
      likes: article.likes,
      comments: article.comments,
      liked: article.liked
    };
  }
};

// 提交回复
const submitReply = async (comment) => {
  const commentId = String(comment.id);
  const text = replyTextMap.value[commentId];
  if (!text || !text.trim()) return;

  if (!currentUser.value) {
    // 未登录，显示登录模态框
    showAuthModal.value = true;
    return;
  }

  try {
    isSubmittingReply.value = true;

    const realCommentId = comment.realId || comment.id;
    console.log('提交回复 - 真实评论ID:', realCommentId);
    console.log('提交回复 - 文章ID:', modalData.value.id);

    if (!realCommentId) {
      ElMessage.error('评论ID不存在，无法回复');
      isSubmittingReply.value = false;
      return;
    }

    // 判断是回复评论还是回复回复
    // 过滤回复内容，移除危险字符
    const sanitizedText = sanitizeContent(text);

    if (replyingToReply.value) {
      // 回复回复
      const realReplyId = replyingToReply.value.id;
      console.log('提交回复回复 - 真实回复ID:', realReplyId);
      await articleAPI.replyReply(
        modalData.value.id ? modalData.value.id.toString() : '',
        realCommentId.toString(),
        realReplyId.toString(),
        sanitizedText
      );
    } else {
      // 回复评论
      await articleAPI.replyComment(
        modalData.value.id ? modalData.value.id.toString() : '',
        realCommentId.toString(),
        sanitizedText
      );
    }

    // 添加回复到评论（临时方案，应该重新获取评论列表）
    if (!comment.replies) {
      comment.replies = [];
    }

    comment.replies.push({
      id: Date.now(),
      username: currentUser.value.username,
      content: text
    });

    // 重新获取评论列表
    const updatedComments = await articleAPI.getArticleComments(
      modalData.value.id ? modalData.value.id.toString() : ''
    );

    // 收集所有需要获取头像的用户名
    const usernameSet = new Set();
    updatedComments.forEach(comment => {
      usernameSet.add(comment.username);
      comment.replies?.forEach((reply) => {
        usernameSet.add(reply.username);
      });
    });

    // 获取所有用户头像
    const avatarPromises = Array.from(usernameSet).map(async (username) => {
      const avatar = await getUserAvatar(username);
      return { username, avatar };
    });
    
    const avatarResults = await Promise.all(avatarPromises);
    const avatarMap = new Map(avatarResults.map(r => [r.username, r.avatar]));

    // 更新评论列表
    modalData.value.commentsList = updatedComments.map((comment) => {
      const commentId = comment.id || comment.comment_id || comment._id || `comment-${Date.now()}`;
      return {
        id: commentId,
        realId: comment.comment_id || comment.id,
        username: comment.username,
        avatar_url: avatarMap.get(comment.username) || '',
        content: comment.content,
        replies: (comment.replies || []).map((reply, replyIndex) => ({
          id: reply.id || reply.reply_id || `reply-${Date.now()}-${replyIndex}`,
          username: reply.username,
          avatar_url: avatarMap.get(reply.username) || '',
          content: reply.content,
          reply_to: reply.reply_to,
          reply_to_user: reply.reply_to_user
        }))
      };
    });

    // 更新评论数量并同步到文章列表
    modalData.value.comments = updatedComments.length;
    syncArticleToList(modalData.value);

    // 清空回复状态并关闭模态框
    cancelReply();

    ElMessage.success('回复成功');
  } catch (error) {
    console.error('提交回复失败:', error);
    ElMessage.error('回复失败');
  } finally {
    isSubmittingReply.value = false;
  }
};

// 确认模态框相关函数
const handleConfirm = async () => {
  if (pendingDeleteAction.value) {
    confirmModalLoading.value = true;
    try {
      await pendingDeleteAction.value();
    } finally {
      confirmModalLoading.value = false;
      showConfirmModal.value = false;
      pendingDeleteAction.value = null;
    }
  }
};

const handleCancel = () => {
  showConfirmModal.value = false;
  pendingDeleteAction.value = null;
};

// 删除评论
const deleteComment = async (comment) => {
  // 显示确认模态框
  confirmModalTitle.value = '确认删除';
  confirmModalMessage.value = '确定要删除这条评论吗？';
  
  pendingDeleteAction.value = async () => {
    try {
      await articleAPI.deleteComment(
        modalData.value.id ? modalData.value.id.toString() : '',
        comment.realId || comment.id ? comment.realId || comment.id.toString() : ''
      );

      // 重新获取评论列表
      const updatedComments = await articleAPI.getArticleComments(
        modalData.value.id ? modalData.value.id.toString() : ''
      );

      // 收集所有需要获取头像的用户名
      const usernameSet = new Set();
      updatedComments.forEach(comment => {
        usernameSet.add(comment.username);
        comment.replies?.forEach((reply) => {
          usernameSet.add(reply.username);
        });
      });

      // 获取所有用户头像
      const avatarPromises = Array.from(usernameSet).map(async (username) => {
        const avatar = await getUserAvatar(username);
        return { username, avatar };
      });
      
      const avatarResults = await Promise.all(avatarPromises);
      const avatarMap = new Map(avatarResults.map(r => [r.username, r.avatar]));

      // 更新评论列表
      modalData.value.commentsList = updatedComments.map((comment) => {
        const commentId = comment.id || comment.comment_id || comment._id || `comment-${Date.now()}`;
        return {
          id: commentId,
          realId: comment.comment_id || comment.id,
          username: comment.username,
          avatar_url: avatarMap.get(comment.username) || '',
          content: comment.content,
          replies: (comment.replies || []).map((reply, replyIndex) => ({
            id: reply.id || reply.reply_id || `reply-${Date.now()}-${replyIndex}`,
            username: reply.username,
            avatar_url: avatarMap.get(reply.username) || '',
            content: reply.content,
            reply_to: reply.reply_to,
            reply_to_user: reply.reply_to_user
          }))
        };
      });

      // 更新评论数量并同步到文章列表
      modalData.value.comments = updatedComments.length;
      syncArticleToList(modalData.value);

      ElMessage.success('评论删除成功');
    } catch (error) {
      console.error('删除评论失败:', error);
      ElMessage.error('删除评论失败');
    }
  };
  
  showConfirmModal.value = true;
};

// 删除回复
const deleteReply = async (comment, reply) => {
  // 显示确认模态框
  confirmModalTitle.value = '确认删除';
  confirmModalMessage.value = '确定要删除这条回复吗？';
  
  pendingDeleteAction.value = async () => {
    try {
      await articleAPI.deleteReply(
        modalData.value.id ? modalData.value.id.toString() : '',
        comment.realId || comment.id ? comment.realId || comment.id.toString() : '',
        reply.id ? reply.id.toString() : ''
      );

      // 重新获取评论列表
      const updatedComments = await articleAPI.getArticleComments(
        modalData.value.id ? modalData.value.id.toString() : ''
      );

      // 收集所有需要获取头像的用户名
      const usernameSet = new Set();
      updatedComments.forEach(comment => {
        usernameSet.add(comment.username);
        comment.replies?.forEach((reply) => {
          usernameSet.add(reply.username);
        });
      });

      // 获取所有用户头像
      const avatarPromises = Array.from(usernameSet).map(async (username) => {
        const avatar = await getUserAvatar(username);
        return { username, avatar };
      });
      
      const avatarResults = await Promise.all(avatarPromises);
      const avatarMap = new Map(avatarResults.map(r => [r.username, r.avatar]));

      // 更新评论列表
      modalData.value.commentsList = updatedComments.map((comment) => {
        const commentId = comment.id || comment.comment_id || comment._id || `comment-${Date.now()}`;
        return {
          id: commentId,
          realId: comment.comment_id || comment.id,
          username: comment.username,
          avatar_url: avatarMap.get(comment.username) || '',
          content: comment.content,
          replies: (comment.replies || []).map((reply, replyIndex) => ({
            id: reply.id || reply.reply_id || `reply-${Date.now()}-${replyIndex}`,
            username: reply.username,
            avatar_url: avatarMap.get(reply.username) || '',
            content: reply.content,
            reply_to: reply.reply_to,
            reply_to_user: reply.reply_to_user
          }))
        };
      });

      // 更新评论数量并同步到文章列表
      modalData.value.comments = updatedComments.length;
      syncArticleToList(modalData.value);

      ElMessage.success('回复删除成功');
    } catch (error) {
      console.error('删除回复失败:', error);
      ElMessage.error('删除回复失败');
    }
  };
  
  showConfirmModal.value = true;
};

// 提交文章评论
const submitArticleComment = async () => {
  if (!articleCommentText.value.trim()) return;

  if (!currentUser.value) {
    // 未登录，显示登录模态框
    showAuthModal.value = true;
    return;
  }

  isSubmittingComment.value = true;

  try {
    // 过滤评论内容，移除危险字符
    const sanitizedContent = sanitizeContent(articleCommentText.value);

    await articleAPI.addComment(
      modalData.value.id ? modalData.value.id.toString() : '',
      sanitizedContent
    );

    // 重新获取评论列表
    const updatedComments = await articleAPI.getArticleComments(
      modalData.value.id ? modalData.value.id.toString() : ''
    );

    // 收集所有需要获取头像的用户名
    const usernameSet = new Set();
    updatedComments.forEach(comment => {
      usernameSet.add(comment.username);
      comment.replies?.forEach((reply) => {
        usernameSet.add(reply.username);
      });
    });

    // 获取所有用户头像
    const avatarPromises = Array.from(usernameSet).map(async (username) => {
      const avatar = await getUserAvatar(username);
      return { username, avatar };
    });
    
    const avatarResults = await Promise.all(avatarPromises);
    const avatarMap = new Map(avatarResults.map(r => [r.username, r.avatar]));

    // 更新评论列表
    modalData.value.commentsList = updatedComments.map((comment) => {
      const commentId = comment.id || comment.comment_id || comment._id || `comment-${Date.now()}`;
      return {
        id: commentId,
        realId: comment.comment_id || comment.id,
        username: comment.username,
        avatar_url: avatarMap.get(comment.username) || '',
        content: comment.content,
        replies: (comment.replies || []).map((reply, replyIndex) => ({
          id: reply.id || reply.reply_id || `reply-${Date.now()}-${replyIndex}`,
          username: reply.username,
          avatar_url: avatarMap.get(reply.username) || '',
          content: reply.content,
          reply_to: reply.reply_to,
          reply_to_user: reply.reply_to_user
        }))
      };
    });

    // 增加评论数量并同步到文章列表
    modalData.value.comments = updatedComments.length;
    syncArticleToList(modalData.value);

    // 清空评论文本
    articleCommentText.value = '';

    ElMessage.success('评论成功');
  } catch (error) {
    console.error('提交评论失败:', error);
    ElMessage.error('评论失败');
  } finally {
    isSubmittingComment.value = false;
  }
};
</script>

<style>
@font-face {
  font-family: 'ZhCnFont';
  src: url('@/assets/zh-cn.ttf') format('truetype');
}

/* 隐藏浏览器自带滚动条 */
::-webkit-scrollbar {
  width: 0px;
}

::-webkit-scrollbar-track {
  background: transparent;
}

::-webkit-scrollbar-thumb {
  background: transparent;
  border-radius: 5px;
}

::-webkit-scrollbar-thumb:hover {
  background: transparent;
}

* {
  font-family: 'ZhCnFont', sans-serif !important;
  box-sizing: border-box;
  /* 优化图片渲染 */
  image-rendering: -webkit-optimize-contrast;
  /* 禁止用户选择任何内容 */
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  cursor: url('@/assets/cursor.png'), auto;
}



body,
html {
  margin: 0;
  padding: 0;
  background-color: #000;
  width: 100%;
  height: 100%;
  cursor: url('@/assets/cursor.png'), auto;
}

.raw-image {
  width: auto !important;
  height: auto !important;
  max-width: none !important;
  display: block;
  margin: 0 auto;
}

.line-bottom {
  color: white;
}
</style>

<style scoped>
.screen-wrapper {
  width: 100vw;
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  background: #ffffff;
  overflow: hidden;
  position: relative;
}

.tablet-viewport {
  position: relative;
  /* 初始固定尺寸，但会被JavaScript动态调整 */
  width: 1920px;
  height: 1080px;
  background-color: red;
  overflow: hidden;

  /* --- 新增：物理感边框设置 --- */
  border: 18px solid #1a1a1a;
  /* 模拟屏幕外层黑边，按比例调整 */
  border-radius: 54px;
  /* 让平板看起来有圆角，按比例调整 */

  /* 组合阴影：
     1. 第一层：内部细微高光，模拟玻璃边缘
     2. 第二层：外层厚重阴影，让平板“悬浮”在背景上
     3. 第三层：环境光遮蔽 (Ambient Occlusion) 效果
  */
  box-shadow:
    inset 0 0 6px rgba(255, 255, 255, 0.2),
    0 0 0 6px #333,
    0 45px 150px rgba(0, 0, 0, 0.8),
    0 15px 30px rgba(0, 0, 0, 0.5);

  /* 缩放中心 */
  transform-origin: center center;
  will-change: transform, width, height;
  z-index: 10;
}

.exm-overlay {
  position: absolute;
  inset: 0;
  z-index: 2;
  background-color: red;
}

.exm-opacity {
  opacity: 0.2;
}

.fixed-header {
  position: absolute;
  top: 60px;
  left: 60px;
  display: flex;
  align-items: center;
  z-index: 100;
}

.header-text {
  margin-left: 22.5px;
}

.line-top {
  color: #ffe49f;
  font-weight: bold;
  font-size: 24px;
}

.bg-sidebar {
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  width: 100%;
  /* 使用100%而不是固定宽度 */
  z-index: 3;
  background: red url('@/assets/bg.png') no-repeat left top;
  background-size: cover;
  /* 让背景图片适应容器 */
  transition: width 1.2s cubic-bezier(0.16, 1, 0.3, 1);
}

.bg-sidebar.is-shrunk {
  width: 300px;
}

.bg-w-overlay {
  position: absolute;
  top: 0;
  left: 100%;
  width: 2000px;
  height: 100%;
  background: red url('@/assets/bg_w.png') no-repeat left top;
  background-size: cover;
  z-index: 5;
  /* 确保右侧内容区域在它之上显示 */
}

.sidebar-content {
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
  padding: 180px 30px 75px;
  opacity: 0;
  transition: opacity 0.6s ease;
}

.content-visible {
  opacity: 1;
}

.side-logo-margin {
  margin-bottom: 30px;
  max-width: 180px;
  max-height: 180px;
}

.qipao-container {
  position: relative;
}

.qipao-text-area {
  position: absolute;
  left: 69px;
  top: 81px;
  width: 123px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 19.5px;
  color: #000;
  font-weight: bold;
}

.qipao-container img {
  max-width: 150px;
  max-height: 150px;
}

.icon-group {
  display: flex;
  gap: 18px;
  margin-bottom: 30px;
}

.svg-btn {
  width: 63px;
  height: 63px;
  background: rgba(255, 210, 117, 0.7);
  /* #ffd275 with 0.7 opacity */
  border-radius: 19.5px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;
}

.svg-btn:hover {
  background: rgba(252, 198, 93, 0.9);
  /* #fcc65d with 0.9 opacity */
}

.svg-btn:active {
  background: rgba(255, 210, 117, 0.7);
  /* #ffd275 with 0.7 opacity */
}

.sponsor-label {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 15px;
  margin-bottom: 30px;
  color: #fff;
  font-size: 21px;
  transition: color 0.3s ease;
}


.contact-us {
  width: 210px;
  height: 35px;
  background: rgba(244, 112, 38, 0.3);
  /* #f47026 with 0.7 opacity */
  border: none;
  border-radius: 30px;
  color: white;
  font-size: 21px;
  transition: all 0.3s ease;
}

.contact-us:hover {
  background: rgba(224, 100, 32, 0.9);
  /* #e06420 with 0.9 opacity */
}

.login-btn {
  width: 210px;
  height: 35px;
  background: rgba(237, 143, 35, 0.3);
  /* #ed8f23 with 0.3 opacity */
  border: none;
  border-radius: 30px;
  color: white;
  font-size: 21px;
  transition: all 0.3s ease;
}

.login-btn:hover {
  background: rgba(216, 127, 31, 0.9);
  /* #d87f1f with 0.9 opacity */
}

/* 侧边栏登录按钮 - 铺满宽度 */
.sidebar-login-btn {
  width: 210px !important;
  min-width: 210px !important;
  padding: 8px 20px !important;
  font-size: 21px !important;
}

/* 用户操作容器 */
.user-actions-container {
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

/* 用户操作按钮 */
.user-actions-buttons {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-top: 8px;
}

.user-action-btn {
  width: 210px !important;
  min-width: 210px !important;
  padding: 8px 20px !important;
  font-size: 15px !important;
}

.user-action-btn.logout-btn {
  background: linear-gradient(135deg, #ff4d4f, #ff7875) !important;
}

.user-action-btn.logout-btn:hover {
  background: linear-gradient(135deg, #ff7875, #ff4d4f) !important;
}

.contact-us:active {
  background: rgba(244, 112, 38, 0.7);
  /* #f47026 with 0.7 opacity */
}

.dot {
  width: 9px;
  height: 9px;
  background-color: white;
  border-radius: 50%;
}

.center-logo-wrapper {
  position: absolute;
  inset: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 50;
  pointer-events: none;
}

.main-logo-anim {
  animation: customZoomOut 1.5s cubic-bezier(0.16, 1, 0.3, 1) forwards;
}

.portrait-blocker {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background-color: #000;
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999;
}

.right-content-area {
  position: absolute;
  top: 0;
  left: 300px;
  /* 与收缩后的侧边栏宽度一致 */
  width: calc(100% - 300px);
  /* 剩余宽度 */
  height: 100%;
  display: flex;
  flex-direction: column;
  z-index: 20;
  /* 确保在bg-w-overlay之上显示 */
  opacity: 0;
  transition: opacity 0.5s ease;
}

.right-content-area.content-visible {
  opacity: 1;
}

.top-fixed-bar {
  display: grid;
  grid-template-rows: 20px 20px;
  padding: 0 30px;
  /* 左右都给 */
  padding-top: 30px;
  padding-bottom: 30px;

}

.content-container {
  overflow-y: auto;

  mask-image: linear-gradient(to bottom,
      transparent,
      black 20px);

  -webkit-mask-image: linear-gradient(to bottom,
      transparent,
      black 20px);
}

/* 第一行 */
.top-row {
  display: flex;
  align-items: center;
  gap: 20px;
  height: 10px;
}

.line {
  flex: 1;
  height: 1px;
  background: #ccc;
}

/* 第二行 */
.bottom-row {
  display: flex;
  justify-content: flex-end;
  height: 40px;
  border-bottom: 1px solid #ccc;
}

.ctcake-text {
  font-size: 20px;
  color: #333;
}


.back-button {
  grid-row: 1 / 3;
  justify-self: end;
  align-self: center;
}

.back-icon {
  width: 100%;
  height: 100%;
  object-fit: contain;
}


.content-container {
  flex: 1;
  overflow-y: auto;
  padding-left: 90px;
  padding-right: 90px;
  padding-top: 15px;
  padding-bottom: 20px;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  gap: 25px;
  /* 卡片间距 */
}



/* 发帖按钮区域 */
.create-post-section {
  padding: 20px 0;
  display: flex;
  justify-content: flex-end;
}

.create-post-btn {
  width: auto;
  min-width: 150px;
}

.list-item-card {
  background: #fff;
  border-radius: 20px;
  border: 1px solid #ddd;
  padding: 25px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
  transition: 0.3s;

}

.list-item-card:hover {
  background-color: #e8e1cf;
}

.card-content {

  display: flex;

  flex-direction: row;

  gap: 20px;

  align-items: flex-start;

}



.card-text-content {

  flex: 1;

  display: flex;

  flex-direction: column;

  gap: 15px;

  min-width: 0;
  /* 允许flex项目收缩 */

}

.card-text-content.full-width {
  flex: 1 1 100%;
  /* 当没有图片时，文本内容占据全部宽度 */
}





.card-image-container {

  width: 300px;
  /* 固定图片容器宽度 */

  height: 168.75px;
  /* 16:9比例: 300 * 9/16 */

  border-radius: 10px;

  overflow: hidden;

  flex-shrink: 0;

  position: relative;
  /* 为渐变遮罩提供定位上下文 */
}



.card-image {

  width: 100%;

  height: 100%;

  object-fit: cover;
  /* 图片缩放铺满整个容器 */

}



.card-title {

  font-size: 28px;

  font-weight: bold;

  color: #333;

  white-space: nowrap;

  overflow: hidden;

  text-overflow: ellipsis;

}

.divider {
  height: 2px;
  background-color: #e5e5e5;
  border: none;
  margin-top: 5px;
  margin-bottom: 15px;

}


.card-tag {

  font-size: 20px;

  color: #d58a4e;

  /* 橙色强调色 */

  display: inline-block;

  padding: 5px 15px;

  background: rgba(244, 112, 38, 0.1);

  border-radius: 15px;

  width: fit-content;

}



.card-summary {

  font-size: 28px;

  color: #666;

  line-height: 1.6;

  white-space: nowrap;

  overflow: hidden;

  text-overflow: ellipsis;

}



.card-footer {

  display: flex;

  align-items: center;

  justify-content: space-between;

  margin-top: 10px;

  min-width: 0;
  /* 允许收缩 */

}



.user-info {

  display: flex;

  align-items: center;

  gap: 15px;

  min-width: 0;
  /* 允许收缩 */

}



.username {

  display: flex;

  align-items: center;

  gap: 5px;

  min-width: 0;
  /* 允许收缩 */

}



.username-text {

  font-size: 20px;

  color: #8e8f90;

  white-space: nowrap;

  overflow: hidden;

  text-overflow: ellipsis;

}



.username-tag {

  background: #c8c2b9;

  color: #fefefe;

  padding: 5px 10px;

  border-radius: 0;

  /* 无圆角的长方形 */

  font-size: 18px;

  display: inline-block;

  flex-shrink: 0;

}



.interaction-data {

  display: flex;

  gap: 20px;

  font-size: 18px;

  color: #666;

  flex-shrink: 0;

}

.card-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 10px;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 15px;
}

.avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: #ccc;
  object-fit: cover;
}

.avatar:empty {
  background: #ccc;
}

.username {
  display: flex;
  align-items: center;
  gap: 5px;
}

.username-text {
  font-size: 20px;
  color: #8e8f90;
}

.username-tag {
  background: #c8c2b9;
  color: #fefefe;
  padding: 5px 10px;
  border-radius: 0;
  /* 无圆角的长方形 */
  font-size: 18px;
  display: inline-block;

}

.interaction-data {
  display: flex;
  gap: 20px;
  font-size: 18px;
  color: #666;
}

.like-container {

  display: flex;

  align-items: center;

  gap: 5px;

  padding: 5px;

  border-radius: 5px;

  transition: background-color 0.2s ease;

}



.like-icon-wrapper {



  position: relative;



  width: 18px;



  height: 18px;



  cursor: pointer;



}







.like-icon {



  position: absolute;



  inset: 0;



  width: 100%;



  height: 100%;



  object-fit: contain;



  transition: opacity 0.25s ease;



}







.empty {



  opacity: 1;



  transition: opacity 0.25s ease;



}







.empty.hovered {



  opacity: 0;
  /* hover时透明度变化，配合filled图标显示 */



}







.filled {



  opacity: 0;



  transition: opacity 0.25s ease;



}







.filled.active {



  opacity: 1;



}







.filled.hovered:not(.active) {



  opacity: 0.7;
  /* 未点赞但hover时，实心图标显示部分透明度 */



}







.filled.active.hovered {



  opacity: 1;
  /* 已点赞且hover时，保持实心图标完全显示 */



}







.like-count-text {



  font-size: 18px;



  color: #666;



}







.comment-container {



  display: flex;



  align-items: center;



  gap: 5px;



}







.comment-icon {







  width: 18px;







  height: 18px;







  object-fit: contain;







}







.comment-count-text {



  font-size: 18px;



  color: #666;



}

.right-status-bar {
  position: absolute;
  top: 80px;
  /* 避开顶部固定条 */
  right: 0;
  width: 10px;
  height: calc(100% - 80px);
  background: rgba(255, 210, 117, 0.3);
  /* 浅橙色 */
  z-index: 99;
}

.scroll-indicator {
  width: 100%;
  height: 100px;
  background: #ed8f23;
  /* 橙色 */
  position: absolute;
  top: 0;
  border-radius: 5px;
}

.preloader {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background: linear-gradient(180deg, #f5f5f5 0%, #e8e8e8 100%);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  z-index: 9999;
  overflow: hidden;
}

/* 背景动画层 */
.preloader-bg-animation {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 0;
}

.circle {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 100vmax;
  height: 100vmax;
  transform: translate(-50%, -50%) scale(0);
  border-radius: 50%;
  opacity: 0;
}

.circle-blue {
  background: rgba(0, 136, 255, 0.3);
  animation: circleExpandBlue 2s ease-out infinite;
}

.circle-orange {
  background: rgba(237, 143, 35, 0.3);
  animation: circleExpandOrange 2s ease-out infinite;
}

@keyframes circleExpandBlue {
  0% {
    transform: translate(-50%, -50%) scale(0);
    opacity: 0;
  }

  50% {
    opacity: 1;
  }

  100% {
    transform: translate(-50%, -50%) scale(2);
    opacity: 0;
  }
}

@keyframes circleExpandOrange {

  0%,
  50% {
    transform: translate(-50%, -50%) scale(0);
    opacity: 0;
  }

  75% {
    opacity: 1;
  }

  100% {
    transform: translate(-50%, -50%) scale(2);
    opacity: 0;
  }
}

.loading-logo {
  width: 200px;
  height: 200px;
  margin-bottom: 40px;
  animation: pulse 2s ease-in-out infinite;
  position: relative;
  z-index: 1;
}

.loading-logo img {
  width: 100%;
  height: 100%;
  object-fit: contain;
}

@keyframes pulse {

  0%,
  100% {
    opacity: 1;
  }

  50% {
    opacity: 0.8;
  }
}

.loading-spinner {
  margin-bottom: 30px;
  width: 60px;
  height: 60px;
  position: relative;
  z-index: 1;
}

.loading-circle {
  width: 100%;
  height: 100%;
  animation: spin 1s linear infinite;
}

.loading-path {
  stroke: #ed8f23;
  stroke-linecap: round;
  stroke-dasharray: 90, 150;
  stroke-dashoffset: 0;
  animation: dash 1.5s ease-in-out infinite;
}

@keyframes spin {
  100% {
    transform: rotate(360deg);
  }
}

@keyframes dash {
  0% {
    stroke-dasharray: 1, 150;
    stroke-dashoffset: 0;
  }
  50% {
    stroke-dasharray: 90, 150;
    stroke-dashoffset: -35;
  }
  100% {
    stroke-dasharray: 90, 150;
    stroke-dashoffset: -124;
  }
}

.loading-text {
  color: #333;
  font-size: 18px;
  font-weight: 400;
  letter-spacing: 1px;
  position: relative;
  z-index: 1;
}

.portrait-message {
  color: white;
  font-size: 24px;
  text-align: center;
}

@keyframes customZoomOut {
  0% {
    transform: scale(1);
    opacity: 1;
  }

  30% {
    transform: scale(1.1);
    opacity: 1;
  }

  100% {
    transform: scale(0);
    opacity: 0;
  }
}

/* 模态框样式 */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  backdrop-filter: blur(0px);
  /* 初始无blur */
  opacity: 0;
  animation: fadeInOverlay 0.2s ease-out forwards;
}

.modal-overlay.show {
  background-color: rgba(0, 0, 0, 0.5);
  opacity: 1;
  backdrop-filter: blur(5px);
  /* 显示时有blur */
  animation: fadeInOverlayWithBlur 0.2s ease-out forwards;
}

.modal-overlay.hiding {
  animation: fadeOutOverlayWithBlur 0.2s ease-in forwards;
}

.modal-container {

  width: 85vw;
  /* 屏幕宽度的85% */

  height: 60vh;
  /* 屏幕高度的60% - 进一步降低高度 */

  max-width: 1200px;
  /* 最大宽度限制 */

  max-height: 600px;
  /* 最大高度限制 - 进一步降低最大高度 */

  background-color: white;

  border-radius: 10px 10px 0 0;
  /* 只保留顶部圆角 */

  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);

  display: flex;

  flex-direction: column;

  transform: translateY(-100px);
  /* 起始位置更高 */

  opacity: 0;

  overflow: hidden;

  position: relative;
  /* 确保底部装饰的定位正确 */

}



.modal-bottom-decoration {
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 60px;
  overflow: hidden;
  background-image: url('@/assets/tiezi_di_huabian.png');
  background-repeat: repeat-x;
  background-position: left bottom;
  background-size: auto 100%;
}

/* 模态框加载动画 */
.modal-loading-overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: rgba(255, 255, 255, 0.9);
  z-index: 100;
}

.modal-loading-spinner {
  margin-bottom: 15px;
  width: 40px;
  height: 40px;
}

@keyframes rotate {
  from {
    transform: rotate(0deg);
  }

  to {
    transform: rotate(360deg);
  }
}

.modal-loading-text {
  color: #666;
  font-size: 14px;
}



.modal-container.closing {
  animation: slideOutToTop 0.25s ease-in forwards;
}

.modal-header {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  padding: 15px 20px 10px;
}

.modal-header.no-image-header {
  justify-content: flex-end;
}

.modal-title {
  width: 100%;
  height: 80px;
  display: block;
}

.modal-close {
  background: none;
  border: none;
  cursor: pointer;
  width: 30px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  transition: background-color 0.2s;
  padding: 0;
}

.modal-close:hover {
  background-color: #f0f0f0;
}

/* 灰色外圈 */
.layer-gray {
  font-size: 40px;
  font-weight: 600;
  fill: none;
  stroke: #ccc;
  stroke-width: 18;
  stroke-linejoin: round;
}

/* 白色中圈 */
.layer-white {
  font-size: 40px;
  font-weight: 600;
  fill: none;
  stroke: #fff;
  stroke-width: 10;
  stroke-linejoin: round;
}

/* 黑色正文 */
.layer-black {
  font-size: 40px;
  font-weight: 600;
  fill: #000;
}

.modal-user-info {
  display: flex;
  align-items: center;
  padding: 0 20px 15px;
  gap: 10px;
}

.user-avatar {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  background: #ccc;
  object-fit: cover;
}

.user-avatar:empty {
  background: #ccc;
}

.username {
  font-size: 14px;
  color: #666;
  flex: 1;
  display: flex;
  align-items: center;
  gap: 5px;
}

.ip-location {
  display: flex;
  align-items: center;
  gap: 4px;
  background: #f0f0f0;
  padding: 4px 8px;
  border-radius: 5px;
  font-size: 12px;
  color: #666;
}

.location-icon {
  width: 14px;
  height: 14px;
  object-fit: contain;
}

.modal-close {
  background: none;
  border: none;
  cursor: pointer;
  width: 30px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  transition: background-color 0.2s;
  padding: 0;
}

.modal-close:hover {
  background-color: #f0f0f0;
}

.close-icon {
  width: 16px;
  height: 16px;
  object-fit: contain;
}

.modal-content {
  display: flex;
  flex: 1;
  overflow: hidden;
  opacity: 0;
  animation: contentFadeIn 0.3s ease-out 0.1s forwards;
  /* 稍微慢一点 */
  padding-bottom: 40px;
  /* 为底部装饰区域留出空间 */
  margin-bottom: 40px;
  /* 为底部装饰区域留出空间 */
}

.modal-container.closing .modal-content {
  animation: contentFadeOut 0.25s ease-in forwards;
  /* 稍微慢一点 */
}

.modal-left {
  flex: 0 0 50%;
  /* 占50%宽度，减少图片区域宽度 */
  padding: 15px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.modal-left.no-image {
  display: none;
  /* 当没有图片时，隐藏左侧图片区域 */
}

.modal-left-content {
  height: 100%;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.modal-image-container {
  flex: 1;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  max-height: 70%;
  /* 限制图片容器的最大高度 */
  position: relative;
  /* 为渐变遮罩提供定位上下文 */
  width: 100%;
  max-width: 370px;
  /* 最大宽度 */
  margin: 0 auto;
  /* 水平居中 */

  aspect-ratio: 16 / 9;
  /* 强制 16:9 */
  display: flex;
  justify-content: center;
  align-items: center;
  background: #f5f5f5;
}

.modal-image {
  width: 100%;
  height: 100%;
}

.modal-image :deep(.el-image__inner) {
  width: 100%;
  height: 100%;
  object-fit: contain;
}

/* 图片加载错误时的样式 */
.image-slot {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  width: 100%;
  height: 100%;
  background: var(--el-fill-color-light);
  color: var(--el-text-color-secondary);
  gap: 10px;
}

.image-error-text {
  font-size: 14px;
  margin-top: 8px;
}

.viewer-error {
  color: #000;
}


.modal-tags {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.modal-tag {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 6px 10px;
  border-radius: 999px;
  background: #f3f4f6;
  font-size: 12px;
}

.tag-icon {
  font-size: 10px;
}

.tag-text {
  color: #6b7280;
}

.modal-right {
  flex: 0 0 50%;
  /* 占50%宽度，与左边部分平衡 */
  border-left: 1px solid #eee;
  display: flex;
  flex-direction: column;
}

.modal-right.no-image {
  flex: 0 0 100%;
  /* 当没有图片时，右侧内容占据全部宽度 */
  border-left: none;
  /* 移除左侧边框，因为没有分隔了 */
}

.modal-right-content {
  padding: 15px;
  height: 100%;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.modal-article-content {
  overflow-y: auto;
  margin-bottom: 10px;
  padding-right: 5px;
  /* 为滚动条留出空间 */
}

.modal-article-content::-webkit-scrollbar {
  width: 6px;
}

.modal-article-content::-webkit-scrollbar-track {
  background: #f1f1f1;
  border-radius: 3px;
}

.modal-article-content::-webkit-scrollbar-thumb {
  background: #c1c1c1;
  border-radius: 3px;
}

.modal-article-content::-webkit-scrollbar-thumb:hover {
  background: #a8a8a8;
}

.modal-article-text {
  font-size: 14px;
  line-height: 1.6;
  color: #333;
  white-space: normal;
}

/* 文章富文本内容样式 */
.article-html-content {
  width: 100%;
}

.article-html-content h1,
.article-html-content h2,
.article-html-content h3,
.article-html-content h4,
.article-html-content h5,
.article-html-content h6 {
  margin: 16px 0 8px;
  font-weight: 600;
  color: #333;
}

.article-html-content h1 { font-size: 24px; }
.article-html-content h2 { font-size: 20px; }
.article-html-content h3 { font-size: 18px; }
.article-html-content h4 { font-size: 16px; }
.article-html-content h5 { font-size: 14px; }
.article-html-content h6 { font-size: 12px; }

.article-html-content p {
  margin: 8px 0;
  line-height: 1.6;
}

.article-html-content strong {
  font-weight: 600;
}

.article-html-content em {
  font-style: italic;
}

.article-html-content u {
  text-decoration: underline;
}

.article-html-content s {
  text-decoration: line-through;
}

.article-html-content ul,
.article-html-content ol {
  margin: 12px 0;
  padding-left: 24px;
}

.article-html-content li {
  margin: 4px 0;
  line-height: 1.6;
}

.article-html-content blockquote {
  border-left: 4px solid #ed8f23;
  padding-left: 12px;
  margin: 12px 0;
  color: #666;
  font-style: italic;
}

.article-html-content pre {
  background: #f5f5f5;
  border-radius: 4px;
  padding: 12px;
  overflow-x: auto;
  font-family: 'Courier New', monospace;
  font-size: 13px;
  line-height: 1.6;
  margin: 12px 0;
}

.article-html-content code {
  background: #f5f5f5;
  padding: 2px 6px;
  border-radius: 3px;
  font-family: 'Courier New', monospace;
  font-size: 13px;
}

.article-html-content a {
  color: #ed8f23;
  text-decoration: underline;
}

.article-html-content a:hover {
  color: #d87f1f;
}

.article-html-content hr {
  border: none;
  border-top: 2px solid #e0e0e0;
  margin: 16px 0;
}

.article-html-content img {
  max-width: 100%;
  height: auto;
  border-radius: 4px;
  margin: 8px 0;
}

.modal-article-line {
  display: block;
}

.modal-interactions {
  display: flex;
  justify-content: flex-end;
  gap: 15px;
  padding: 10px 0;
  margin-top: auto;
}

.modal-comments {
  margin-top: 10px;
  flex: 1;
  overflow-y: auto;
  height: 250px;
}

/* 文章评论输入框 */
.article-comment-input {
  margin-bottom: 20px;
  padding: 15px;
  background: #f9f9f9;
  border-radius: 8px;
   text-align: right;
}

.article-comment-input .hsr-input-wrapper {
  width: 100%;
}

.comment-submit-btn {
  margin-left: auto;
  margin-top: 12px;

}

.comment-textarea {
  width: 100%;
  min-height: 80px;
  padding: 12px;
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  resize: vertical;
  font-size: 14px;
  font-family: inherit;
  margin-bottom: 10px;
  box-sizing: border-box;
}

.comment-textarea:focus {
  outline: none;
  border-color: #409eff;
}

.submit-comment-button {
  float: right;
  padding: 8px 20px;
  background: #409eff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  transition: background 0.2s;
}

.submit-comment-button:hover {
  background: #66b1ff;
}

.modal-comments::-webkit-scrollbar {
  width: 6px;
}

.modal-comments::-webkit-scrollbar-track {
  background: #f1f1f1;
  border-radius: 3px;
}

.modal-comments::-webkit-scrollbar-thumb {
  background: #c1c1c1;
  border-radius: 3px;
}

.modal-comments::-webkit-scrollbar-thumb:hover {
  background: #a8a8a8;
}

.comment-item {
  display: flex;
  gap: 12px;
  margin-bottom: 16px;
  padding-bottom: 16px;
  border-bottom: 1px solid #e8e8e8;
  cursor: pointer;
  transition: background-color 0.2s ease;
}

.comment-item:hover {
  background-color: rgba(0, 0, 0, 0.02);
  border-radius: 8px;
}

.comment-item:last-child {
  border-bottom: none;
}

.comment-avatar {
  width: 40px;
  height: 40px;

  border-radius: 50%;
  background: #ccc;
  object-fit: cover;
}

.comment-avatar:empty {
  background: #ccc;
}

.comment-content {
  flex: 1;
}

.comment-username {
  font-size: 12px;
  color: #8e8f90;
  margin-bottom: 4px;
}

.comment-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 4px;
}

.comment-actions {
  display: flex;
  align-items: center;
  gap: 8px;
}

.reply-icon-btn {
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  border-radius: 6px;
  transition: all 0.2s ease;
  color: #666;
  flex-shrink: 0;
  margin-left: 8px;
  border: 1px solid #e0e0e0;
  background: #fafafa;
}

.reply-icon-btn:hover {
  background: #ed8f23;
  border-color: #ed8f23;
  color: white;
  box-shadow: 0 2px 8px rgba(237, 143, 35, 0.3);
}

.reply-icon {
  width: 18px;
  height: 18px;
  display: block;
}

.delete-icon-btn {
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  border-radius: 6px;
  transition: all 0.2s ease;
  color: #666;
  flex-shrink: 0;
  margin-left: 8px;
  border: 1px solid #e0e0e0;
  background: #fafafa;
}

.delete-icon-btn:hover {
  background: #ff4d4f;
  border-color: #ff4d4f;
  color: white;
  box-shadow: 0 2px 8px rgba(255, 77, 79, 0.3);
}

.reply-icon {
  width: 20px;
  height: 20px;
  display: block;
}

.delete-icon {
  width: 20px;
  height: 20px;
  display: block;
}

/* 内联回复输入框 */
.reply-input-inline {
  margin-top: 12px;
  padding: 12px;
  background: #f8f9fa;
  border-radius: 8px;
  border-left: 3px solid #ed8f23;
  animation: slideDown 0.2s ease;
}

@keyframes slideDown {
  from {
    opacity: 0;
    transform: translateY(-8px);
  }

  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.reply-input-textarea {
  width: 100%;
  padding: 10px 12px;
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  font-size: 14px;
  font-family: inherit;
  resize: none;
  background: white;
  transition: all 0.2s ease;
}

.reply-input-textarea:focus {
  outline: none;
  border-color: #ed8f23;
  box-shadow: 0 0 0 3px rgba(237, 143, 35, 0.1);
}

.reply-input-actions {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  margin-top: 8px;
}

/* 原有的回复输入框样式保留兼容 */
.reply-input-container {
  margin-top: 10px;
  padding: 10px;
  background: #f9f9f9;
  border-radius: 6px;
}

.reply-input {
  width: 100%;
  padding: 8px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 13px;
  resize: none;
  font-family: inherit;
}

.reply-input:focus {
  outline: none;
  border-color: #ed8f23;
}

.reply-actions {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  margin-top: 8px;
}

.comment-text {
  font-size: 14px;
  color: #333;
  line-height: 1.4;
}

/* 回复样式 */
.comment-replies {
  margin-top: 10px;
  padding-left: 20px;
  /* 缩进 */
}

.reply-item {
  display: flex;
  gap: 10px;
  margin-bottom: 8px;
  padding: 8px;
  border-radius: 6px;
  cursor: pointer;
  transition: background-color 0.2s ease;
}

.reply-item:hover {
  background-color: rgba(0, 0, 0, 0.03);
}

.reply-highlight {
  background-color: rgba(237, 143, 35, 0.2);
  transition: background-color 0.3s ease;
}

.reply-avatar {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  background: #ccc;
  object-fit: cover;
}

.reply-avatar:empty {
  background: #ccc;
}

.reply-content {
  flex: 1;
}

.reply-username {
  font-size: 12px;
  color: #666;
  margin-bottom: 4px;
  font-weight: 500;
}

.reply-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 4px;
}

.reply-actions {
  display: flex;
  gap: 8px;
}

.reply-text {
  font-size: 13px;
  color: #333;
  line-height: 1.4;
}

.reply-mention {
  color: #ed8f23;
  font-weight: 600;
  background: rgba(237, 143, 35, 0.1);
  padding: 2px 6px;
  border-radius: 4px;
}

.reply-mention.clickable {
  cursor: pointer;
  transition: all 0.2s ease;
}

.reply-mention.clickable:hover {
  background: rgba(237, 143, 35, 0.2);
  text-decoration: underline;
}

/* 回复按钮 */
.reply-button {
  margin-top: 8px;
  padding: 4px 12px;
  background: #f0f0f0;
  border: none;
  border-radius: 4px;
  font-size: 12px;
  color: #666;
  cursor: pointer;
  transition: background-color 0.2s;
}

.reply-button:hover {
  background: #e0e0e0;
}

/* 回复输入框容器 */
.reply-input-container {
  margin-top: 10px;
  padding: 10px;
  background: #f9f9f9;
  border-radius: 6px;
}

.reply-input {
  width: 100%;
  padding: 8px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 13px;
  resize: none;
  font-family: inherit;
}

.reply-input:focus {
  outline: none;
  border-color: #ed8f23;
}

/* 回复操作按钮 */
.reply-actions {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  margin-top: 8px;
}

.cancel-reply-button {
  padding: 4px 12px;
  background: #f0f0f0;
  border: none;
  border-radius: 4px;
  font-size: 12px;
  color: #666;
  cursor: pointer;
  transition: background-color 0.2s;
}

.cancel-reply-button:hover {
  background: #e0e0e0;
}

.submit-reply-button {
  padding: 4px 12px;
  background: #ed8f23;
  border: none;
  border-radius: 4px;
  font-size: 12px;
  color: white;
  cursor: pointer;
  transition: background-color 0.2s;
}

.submit-reply-button:hover {
  background: #d87f1f;
}

/* 动画效果 */
@keyframes fadeInOverlay {
  from {
    background-color: rgba(0, 0, 0, 0);
    opacity: 0;
  }

  to {
    background-color: rgba(0, 0, 0, 0.5);
    opacity: 1;
  }
}

@keyframes fadeInOverlayWithBlur {
  from {
    background-color: rgba(0, 0, 0, 0);
    opacity: 0;
    backdrop-filter: blur(0px);
  }

  to {
    background-color: rgba(0, 0, 0, 0.5);
    opacity: 1;
    backdrop-filter: blur(5px);
  }
}

@keyframes fadeOutOverlayWithBlur {
  from {
    background-color: rgba(0, 0, 0, 0.5);
    opacity: 1;
    backdrop-filter: blur(5px);
  }

  to {
    background-color: rgba(0, 0, 0, 0);
    opacity: 0;
    backdrop-filter: blur(0px);
  }
}

@keyframes slideInFromTop {
  from {
    transform: translateY(-100px);
    opacity: 0;
  }

  to {
    transform: translateY(0);
    opacity: 1;
  }
}

@keyframes slideOutToTop {
  from {
    transform: translateY(0);
    opacity: 1;
  }

  to {
    transform: translateY(-100px);
    opacity: 0;
  }
}

/* 使用更明显的先快后慢缓动函数 */
.modal-container {
  animation: slideInFromTop 0.3s cubic-bezier(0.16, 0.8, 0.37, 0.99) forwards;
}

.modal-container.closing {
  animation: slideOutToTop 0.25s cubic-bezier(0.16, 0.8, 0.37, 0.99) forwards;
}

@keyframes contentFadeIn {
  from {
    opacity: 0;
  }

  to {
    opacity: 1;
  }
}

@keyframes contentFadeOut {
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
  }
}

/* 回复评论模态框样式 */
.reply-modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  backdrop-filter: blur(4px);
  z-index: 9998;
  display: flex;
  align-items: center;
  justify-content: center;
  animation: fadeIn 0.2s ease;
}

@keyframes fadeIn {
  from {
    opacity: 0;
  }

  to {
    opacity: 1;
  }
}

@keyframes fadeOut {
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
  }
}

.reply-modal-container {
  width: 90%;
  max-width: 600px;
  background: white;
  border-radius: 12px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
  animation: slideUp 0.3s ease;
  overflow: hidden;
}

@keyframes slideUp {
  from {
    opacity: 0;
    transform: translateY(20px);
  }

  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes slideDown {
  from {
    opacity: 1;
    transform: translateY(0);
  }

  to {
    opacity: 0;
    transform: translateY(20px);
  }
}

/* 关闭动画状态 */
.reply-modal-overlay.is-closing {
  animation: fadeOut 0.2s ease forwards;
}

.reply-modal-container.is-closing {
  animation: slideDown 0.2s ease forwards;
}

.reply-modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px 24px;
  border-bottom: 1px solid #f0f0f0;
  background: #fafafa;
}

.reply-modal-title {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
  color: #333;
}

.reply-modal-close {
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  border-radius: 6px;
  transition: all 0.2s ease;
  color: #999;
}

.reply-modal-close:hover {
  background: #f0f0f0;
  color: #333;
}

.reply-close-icon {
  width: 18px;
  height: 18px;
  display: block;
}

.reply-modal-body {
  padding: 24px;
}

.reply-original-content {
  padding: 12px 16px;
  background: #f8f9fa;
  border-radius: 8px;
  margin-bottom: 16px;
  font-size: 14px;
  line-height: 1.6;
}

.reply-original-label {
  color: #999;
  font-weight: 500;
  margin-right: 8px;
}

.reply-original-text {
  color: #666;
}

.reply-modal-textarea {
  width: 100%;
  padding: 12px 16px;
  border: 2px solid #e0e0e0;
  border-radius: 8px;
  font-size: 15px;
  font-family: inherit;
  resize: none;
  transition: all 0.2s ease;
  background: #fafafa;
}

.reply-modal-textarea:focus {
  outline: none;
  border-color: #ed8f23;
  background: white;
  box-shadow: 0 0 0 4px rgba(237, 143, 35, 0.1);
}

.reply-modal-footer {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  padding: 16px 24px;
  border-top: 1px solid #f0f0f0;
  background: #fafafa;
}

/* 禁用按钮样式 */
.reply-modal-footer .sr-action-btn.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

/* 全屏图片查看器样式 */
.image-viewer-error-slot {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
  background: var(--el-fill-color-light);
  color: var(--el-text-color-secondary);
  gap: 16px;
}

.confirm-upload-button:disabled {
  background: #ccc;
  cursor: not-allowed;
}

.cancel-upload-button {
  padding: 8px 20px;
  background: #f0f0f0;
  color: #666;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  transition: background 0.3s ease;
}

.cancel-upload-button:hover {
  background: #e0e0e0;
}
</style>