// API服务模块

const BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';

// 后端响应格式
interface ApiResponse<T> {
  code: number;
  message: string;
  data: T;
}

// 登录响应格式（直接返回token和用户信息，不包装在data中）
interface LoginResponse {
  code: number;
  message: string;
  token: string;
  username: string;
}

// 注册响应格式（直接返回用户信息，不包装在data中）
interface RegisterResponse {
  code: number;
  message: string;
  username: string;
}

// 通用请求函数（处理标准响应格式）
async function request<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const url = `${BASE_URL}${endpoint}`;

  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...options.headers,
  };

  // 添加授权头（如果有token）
  const token = localStorage.getItem('token');
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const config: RequestInit = {
    ...options,
    headers,
  };

  try {
    const response = await fetch(url, config);

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const result: ApiResponse<T> = await response.json();

    // 检查业务状态码
    if (result.code !== 200) {
      throw new Error(`API error: ${result.message}`);
    }

    return result.data;
  } catch (error) {
    console.error('API request failed:', error);
    throw error;
  }
}

// 直接返回完整响应的请求函数（用于注册等特殊接口）
async function requestFullResponse<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const url = `${BASE_URL}${endpoint}`;

  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...options.headers,
  };

  const config: RequestInit = {
    ...options,
    headers,
  };

  try {
    const response = await fetch(url, config);

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const result: T = await response.json();

    // 检查业务状态码
    if ('code' in result && (result as any).code !== 200) {
      throw new Error(`API error: ${(result as any).message}`);
    }

    return result;
  } catch (error) {
    console.error('API request failed:', error);
    throw error;
  }
}

// 用户认证相关API
export const authAPI = {
  // 登录
  login: (username: string, password: string, cfToken?: string) =>
    requestFullResponse<LoginResponse>('/login', {
      method: 'POST',
      body: JSON.stringify({ username, password, cfToken }),
    }),

  // 注册
  register: (username: string, password: string, cfToken?: string) =>
    requestFullResponse<RegisterResponse>('/register', {
      method: 'POST',
      body: JSON.stringify({ username, password, cfToken }),
    }),
};

// 用户相关API
export const userAPI = {
  // 获取用户头像
  getAvatar: (username: string) =>
    request<{ avatar_url: string }>(`/user/avatar?username=${username}`, {
      method: 'GET',
    }),

  // 更新头像（接收base64格式）
  updateAvatar: (avatarBase64: string) =>
    request<any>('/user/avatar', {
      method: 'PUT',
      body: JSON.stringify({ avatar_base64: avatarBase64 }),
    }),
};

// 文章相关API
export const articleAPI = {
  // 获取文章列表
  getArticles: () =>
    request<any[]>('/articles', {
      method: 'GET',
    }),

  // 获取文章详情
  getArticleDetail: (articleId: string) =>
    request<any>(`/article/detail?article_id=${articleId}`, {
      method: 'GET',
    }),

  // 获取文章评论
  getArticleComments: (articleId: string) =>
    request<any[]>(`/article/comments?article_id=${articleId}`, {
      method: 'GET',
    }),

  // 创建文章
  createArticle: (title: string, content: string, imageBase64?: string, board: string = 'default') =>
    request<{ article_id: string; title: string; cover_url: string }>('/article/create', {
      method: 'POST',
      body: JSON.stringify({ title, content, image_base64: imageBase64, board }),
    }),

  // 点赞文章
  likeArticle: (articleId: string) =>
    request<any>('/article/like', {
      method: 'POST',
      body: JSON.stringify({ article_id: articleId }),
    }),

  // 添加评论
  addComment: (articleId: string, content: string) =>
    request<any>('/article/comment', {
      method: 'POST',
      body: JSON.stringify({ article_id: articleId, content }),
    }),

  // 回复评论
  replyComment: (articleId: string, commentId: string, content: string) =>
    request<any>('/article/comment/reply', {
      method: 'POST',
      body: JSON.stringify({ article_id: articleId, comment_id: commentId, content }),
    }),

  // 回复回复
  replyReply: (articleId: string, commentId: string, replyId: string, content: string) =>
    request<any>('/article/comment/reply/reply', {
      method: 'POST',
      body: JSON.stringify({ article_id: articleId, comment_id: commentId, reply_id: replyId, content }),
    }),

  // 删除评论
  deleteComment: (articleId: string, commentId: string) =>
    request<any>('/article/comment', {
      method: 'DELETE',
      body: JSON.stringify({ article_id: articleId, comment_id: commentId }),
    }),

  // 删除回复
  deleteReply: (articleId: string, commentId: string, replyId: string) =>
    request<any>('/article/comment/reply', {
      method: 'DELETE',
      body: JSON.stringify({ article_id: articleId, comment_id: commentId, reply_id: replyId }),
    }),
};

export default { authAPI, userAPI, articleAPI };